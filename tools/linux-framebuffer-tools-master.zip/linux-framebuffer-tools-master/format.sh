find src -name \*.c -exec clang-format -i {} \;
find src -name \*.h -exec clang-format -i {} \;

