# linux-framebuffer-tools

## Some tools for linux framebuffer. 

* gsnap: snap a image from framebuffer. 
* fbshow: show a image on the framebuffer

## Build

```
make
```

## Usage

```
./bin/gsnap
./bin/fbshow
```
