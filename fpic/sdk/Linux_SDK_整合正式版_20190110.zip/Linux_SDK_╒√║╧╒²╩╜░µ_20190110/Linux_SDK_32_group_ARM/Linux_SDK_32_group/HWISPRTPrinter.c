
/************************************************************************
 *
 * SPRT printer SO for linux;
 * Created by qzfeng 2015/09/09
 *
 ***********************************************************************/

#include <stdio.h>
#include <string.h>
#include <libusb.h>
#include "HWISPRTPrinter.h"
#include <pthread.h> 
#include <time.h>
#include <sys/types.h>
#include <dirent.h> 
#include <sys/stat.h>
#include "sprtGraphic.h"

#include <dirent.h> 
#include <sys/stat.h>
#include "sprtGraphic.h"
#include <stdlib.h>     /*标准函数库定义*/
#include <unistd.h>     /*Unix 标准函数定义*/
#include <sys/types.h> 
#include <sys/stat.h>  
#include <fcntl.h>      /*文件控制定义*/
#include <termios.h>    /*PPSIX 终端控制定义*/

//-------------ztongli.2016.12.19--------------
AL al;//通用接口整合，内部使用的全局结构体
//-------------ztongli.2016.12.19--------------

libusb_device_handle *gDev_handle=NULL;      // usb开口句柄;
pthread_mutex_t gPUsb_mutex;						// usb锁;
pthread_mutex_t gPLog_mutex;						// 日志锁;
libusb_context *gCtx=NULL;	

int gLastErrorCode;         // 最近一次的错误码,同上定义;
char gLastErrorStr[1024];   // 最近一次的错误描述，以\0结尾,接口要求最多存储100个字节; 

// 打印机发送指令缓冲区及发送指令长度（字节）;
unsigned char gCmdBuf[1024];
int gCmdBufLen;
// 打印机接收缓冲区及接收返回字节长度;
unsigned char gRcvBuf[1024];
int gRcvBufLen;

unsigned char gFuncName[128];		// 接口函数名称；
unsigned char gParams[128];			// 参数列表；
unsigned char gOtherMsg[1024];	// 其他详细错误信息;
int gOtherMsgLen;				//gOtherMsg的有效长度;

unsigned char gInputDir[256];					// 输入路径;
unsigned char gOutputDir[256];				// 输出路径;

int firstLogTag=0;					// 第一次调用日志函数标志：

int gDoLogFlag=0;									// 日志记录标志，0：不记录日志; 1:记录日志，2：不判断,用于初始记录日志信息;
int gBlack_markFlag=0;						// 1:big大黑标,0:small小黑标;

unsigned char gLogBuf[1024];		// 日志记录缓冲区;

int socketFd=0;					// 网口句柄,WX_20160811
int serialFd=0;					// 串口句柄; qzfeng 2016/05/11

typedef struct
{
	u_int8_t  bInterfaceNumber;
	u_int8_t  bInEndpointAddress;
	u_int8_t  bOutEndpointAddress;
	u_int16_t idVendor;
	u_int16_t idProduct;       
}stUsbCtrl;

stUsbCtrl usbctrl;				//garland 2019-01-08


// 串口开口函数; 返回值: 0 成功，其他失败；
int Sprt_serial_open(char *Dev)
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_open() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	pthread_mutex_lock(&gPUsb_mutex);

	InitGlobalVar();

//	serialFd = open( Dev, O_RDWR | O_NOCTTY | O_NDELAY | O_NONBLOCK );
//	serialFd = open( Dev, O_RDWR | O_NOCTTY | O_NDELAY );
	serialFd = open( Dev, O_RDWR | O_NOCTTY);			// 去除O_NDELAY | O_NONBLOCK，可以支持硬件流控; qzfeng 2016/11/17
	if (-1 == serialFd)        
	{                        
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_open() Can't Open Serial Port, return -1");
		DoLog(gLogBuf,strlen(gLogBuf));
 		pthread_mutex_unlock(&gPUsb_mutex);
	
		return -1;            
	}      
	else  
	{
//		fcntl(serialFd,F_SETFL,0);			// 加上这句也可以支持硬件流控； qzfeng 2016/11/17
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_open() finished.");
		DoLog(gLogBuf,strlen(gLogBuf));
	
		pthread_mutex_unlock(&gPUsb_mutex);

		return 0;
	}

}

// 串口关口函数; 返回值: 0 成功，其他失败；
int Sprt_serial_close()
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_close() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(serialFd!=-1)
	{
		close(serialFd);
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_close() finished.");
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;	
	}
	else
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_close() serialFd==-1");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}		


}

// 串口接收函数; pBufLen为期望接收到的字节个数; 成功：返回值为实际读取的字节数,其他失败;
int Sprt_serial_read(unsigned char *pBuf,int pBufLen,int sleepTime)
{

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_read() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(pBufLen<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_read() pBufLen<0,pBufLen=%d",pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}		
	if((pBufLen==0)||(pBuf==NULL))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_read()  (pBufLen==0)||(pBuf==NULL) pBufLen=%d",pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;
	}		
	
	int sleepTimeUnit=1;				// 1秒;
	int sleepTimeDiv=1;
	if(sleepTime<sleepTimeUnit)
	{
		sleepTimeDiv=1;
	}
	else
	{
		sleepTimeDiv=sleepTime/sleepTimeUnit;
	}				
	pthread_mutex_lock(&gPUsb_mutex);
	
	int ret=-1;
	int count=0;
	unsigned char tempBuf[1024]={0};
  int ii=0;
	count=0;
	for(ii=0; ii<sleepTimeDiv; ii++)
 	{
 		ret = read(serialFd, tempBuf, sizeof(tempBuf));
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_read() 1 read() ii=%d,ret=%d",ii,ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		if(ret>0)
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_read() 2 read() ii=%d,ret=%d",ii,ret);
			DoLog(gLogBuf,strlen(gLogBuf));
		  memcpy((void *)&pBuf[count],(void *)tempBuf,ret);
		  count+=ret;
		}
		if(count==pBufLen)
		{
			break;
		}
		sleep(sleepTimeUnit);
 	}

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_read() finished. count=%d,pBuf[0]=%02x",count,pBuf[0]);
	DoLog(gLogBuf,strlen(gLogBuf));

 	pthread_mutex_unlock(&gPUsb_mutex);

  return count;	

}	

// 串口发送函数; 成功：返回值等于pBufLen，其他失败;
int Sprt_serial_write(unsigned char *pBuf,int pBufLen)
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_write() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	if(pBufLen<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_write() pBufLen<0,pBufLen=%d",pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}		
	if(pBufLen==0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_write() pBufLen=0");
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;
	}		
	pthread_mutex_lock(&gPUsb_mutex);

	unsigned char tempBuf[WRITEBYTEMAX]={0};
	int divInt=pBufLen/WRITEBYTEMAX;
	int modInt=pBufLen%WRITEBYTEMAX;
	int i=0;
	int retNum=0;
	int ret=-1;

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_write() pBufLen=%d,divInt=%d,modInt=%d",pBufLen,divInt,modInt);
	DoLog(gLogBuf,strlen(gLogBuf));

	for( i=0; i<divInt;i++)
	{
		memcpy(tempBuf,(unsigned char *)&pBuf[i*WRITEBYTEMAX],WRITEBYTEMAX);
		ret=write(serialFd,tempBuf,WRITEBYTEMAX);
		if(ret!=WRITEBYTEMAX) 
    {
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_write() write() fail! i=%d,ret=%d",i,ret);
			DoLog(gLogBuf,strlen(gLogBuf));

    	pthread_mutex_unlock(&gPUsb_mutex);
    	
    	return -2;
  	}	    	;
	}
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_serial_write() write() ok! i=%d,divInt=%d,modInt=%d",i,divInt,modInt);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	if(modInt!=0)
	{	
		memcpy(tempBuf,(unsigned char *)&pBuf[i*WRITEBYTEMAX],modInt);
		ret=write(serialFd,tempBuf,modInt);
		if(ret!=modInt) 
    {
    	
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_net_write() libusb_bulk_transfer() fail2! ret=%d,retNum=%d,modInt=%d",ret,retNum,modInt);
			DoLog(gLogBuf,strlen(gLogBuf));

    	pthread_mutex_unlock(&gPUsb_mutex);
    	
    	return -3;
  	}
  }		
  
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_net_write() finished.");
	DoLog(gLogBuf,strlen(gLogBuf));

 	pthread_mutex_unlock(&gPUsb_mutex);

  return pBufLen;
	
}

/**
*@brief  设置串口通信速率
*@param  fd     类型 int  打开串口的文件句柄
*@param  speed  类型 int  串口速度
*@return  void
*/
//int speed_arr[] = { B38400, B19200, B9600, B4800, B2400, B1200, B300,B38400, B19200, B9600, B4800, B2400, B1200, B300 };
//int name_arr[] = {38400,  19200,  9600,  4800,  2400,  1200,  300, 38400,19200,  9600, 4800, 2400, 1200,  300 };
int speed_arr[] = { B115200,B57600,B38400, B19200, B9600, B4800, B2400, B1200, B300 };
int name_arr[] =  {  115200, 57600, 38400,  19200,  9600,  4800,  2400,  1200,  300 };
void Sprt_set_speed(int speed)
{
				 int 				i;
         int   status;
         struct termios   Opt;
         tcgetattr(serialFd, &Opt);
         for ( i= 0;  i < sizeof(speed_arr) / sizeof(int);  i++) {
                   if  (speed == name_arr[i]) {    
                            tcflush(serialFd, TCIOFLUSH);    
                            cfsetispeed(&Opt, speed_arr[i]); 
                            cfsetospeed(&Opt, speed_arr[i]);  
                            status = tcsetattr(serialFd, TCSANOW, &Opt); 
                            if  (status != 0) {       
																sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_set_speed() finished.");
																DoLog(gLogBuf,strlen(gLogBuf));
                                return;    
                            }   
                            tcflush(serialFd,TCIOFLUSH);  
                   } 
         }
}

/**
*	设置串口数据位，停止位和效验位
*	databits 类型  int 数据位   取值 为 7 或者8
*	stopbits 类型  int 停止位   取值为 1 或者2
*	parity  类型  int  效验类型 取值为N,E,O,,S
* 函数返回：<0 失败；=0成功；
*/
int Sprt_set_parity(int databits,int stopbits,int parity)
{
        struct termios options;
        if  ( tcgetattr( serialFd,&options)  !=  0) {
				sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_set_Parity() SetupSerial 1.");
				DoLog(gLogBuf,strlen(gLogBuf));
				return -1;
		}
		options.c_cflag &= ~CSIZE;
		options.c_lflag  &= ~(ICANON | ECHO | ECHOE | ISIG);  /*Input*/
		options.c_oflag  &= ~OPOST;   /*Output*/
 
		switch (databits) /*设置数据位数*/
		{   
			case 7:                
				options.c_cflag |= CS7;
				break;
			case 8:    
				options.c_cflag |= CS8;
				break;  
			default:   
				sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_set_Parity() Unsupported data size.");
				DoLog(gLogBuf,strlen(gLogBuf));
				return -2;
		}
		switch (parity)
		{  
			case 'n':
			case 'N':   
				options.c_cflag &= ~PARENB;   /* Clear parity enable */
				options.c_iflag &= ~INPCK;     /* Enable parity checking */
				break; 
			case 'o':  
			case 'O':    
				options.c_cflag |= (PARODD | PARENB); /* 设置为奇效验*/ 
				options.c_iflag |= INPCK;             /* Disnable parity checking */
				break; 
			case 'e': 
			case 'E':  
				options.c_cflag |= PARENB;     /* Enable parity */   
				options.c_cflag &= ~PARODD;   /* 转换为偶效验*/    
				options.c_iflag |= INPCK;       /* Disnable parity checking */
				break;
			case 'S':
			case 's':  /*as no parity*/  
				options.c_cflag &= ~PARENB;
				options.c_cflag &= ~CSTOPB;
				break; 
			default:  
				sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_set_Parity() Unsupported parity.");
				DoLog(gLogBuf,strlen(gLogBuf));
				return -3;				
		} 
		/* 设置停止位*/ 
		switch (stopbits)
		{  
			case 1:   
				options.c_cflag &= ~CSTOPB; 
				break; 
			case 2:   
				options.c_cflag |= CSTOPB; 
				break;
			default:   
				sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_set_Parity() Unsupported stop bits.");
				DoLog(gLogBuf,strlen(gLogBuf));
				return -4;				
		}
/* Set input parity option */
		if (parity != 'n')  
			options.c_iflag |= INPCK;
		tcflush(serialFd,TCIFLUSH);
		// 如果VTIME和VMIN都取0，即使读取不到任何数据，函数read也会立即返回。
		options.c_cc[VTIME] = 0; /* 设置超时15 seconds*/  
		options.c_cc[VMIN] = 0; /* define the minimum bytes data to be readed*/
		if (tcsetattr(serialFd,TCSANOW,&options) != 0)  
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_set_Parity() SetupSerial 3.");
			DoLog(gLogBuf,strlen(gLogBuf));
			return -5;				
		}
			return 0; 
}


// 接口要求实现的函数;
/*****************************************************************************************************/

/* 
 * 功能：打印机切纸;；
 * 入口参数：
 * 					m:切纸方式, 0:全切,1:半切;
 *					n：切纸前走纸n点行,n=0为缺省3点;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_CutPaper(int m,int n)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((m!=0)&&(m!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() m is invalid(0,1)! m=%d",m);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}
	if(n<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() n<0! n=%d",n);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -2;
	}
	    	
  	
	//切纸前走纸3点行
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x64;
	idx++;
  if(n==0)
	{
  		gCmdBuf[idx] = 0x03;
	}
  	else
  	{
  		gCmdBuf[idx] = (unsigned char)(n&0xff);
  	}
	idx++;
	//全切/半切
	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x56;
	idx++;
	gCmdBuf[idx] = (unsigned char)(m&0xff);
	idx++;	

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

/* for test
	// 发送查询命令;
	gCmdBuf[0]=0x10;
	gCmdBuf[1]=0x04;
	gCmdBuf[2]=0x01;
	gCmdBufLen=3;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	ret=Sprt_serial_write(gCmdBuf,gCmdBufLen,500);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -2;
	}	
	// 读取数据；
	gRcvBufLen=100;
	memset(gRcvBuf,0,sizeof(gRcvBuf));
	ret=Sprt_serial_read(gRcvBuf,gRcvBufLen,200);		
	if(ret<=0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() Sprt_serial_read() fail! ret=%d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		
		return -3;
	}
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() Sprt_serial_read() ret=%d,gRcvBuf[0]=%x",ret,gRcvBuf[0]);
	DoLog(gLogBuf,strlen(gLogBuf));

*/


	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CutPaper() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：打印机进纸（按点）;
 * 入口参数：
 * 					lineDots：进纸点数;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_FeedLines(int lineDots)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_FeedLines() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(lineDots<0)	
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_FeedLines() lineDots<0! lineDots=%d",lineDots);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x4a;
	idx++;
	gCmdBuf[idx] = (unsigned char)(lineDots&0xff);
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_FeedLines() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_FeedLines() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_FeedLines() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}
/* 
 * 功能：初始化打印机状态，清空打印缓冲区 ESC @;
 * 入口参数：
 * 					无;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_ReSet()
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_ReSet() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x40;
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_ReSet() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_ReSet() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_ReSet() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：设置左边距 GS L nl nH （设置成[( nL + nH × 256)  × 横向移动单位)]英寸）;
 * 入口参数：
 * 					pos：距离;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_SetPrintPosition(int pos)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintPosition() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(pos<0)	
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintPosition() pos<0! pos=%d",pos);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x4c;
	idx++;
	gCmdBuf[idx] = (unsigned char)(pos&0xff);
	idx++;
	gCmdBuf[idx] = (unsigned char)((pos>>8)&0xff);
	idx++;
	

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintPosition() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintPosition() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintPosition() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：对齐方式 ESC a n;
 * 入口参数：
 * 					align：0,左对齐，1,居中，2,右对齐;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_AlignType(int align)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_AlignType() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((align!=0)&&(align!=1)&&(align!=2))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_AlignType() align is invalid(0,1,2)! align=%d",align);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x61;
	idx++;
	gCmdBuf[idx] = (unsigned char)(align&0xff);
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_AlignType() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_AlignType() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_AlignType() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}


/* 
 * 功能：打印数据并向前走纸若干行 ESC d n;
 * 入口参数：
 * 					lines：行数;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Output_PrintBuffAndFeedLines(int lines)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBuffAndFeedLines() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(lines<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBuffAndFeedLines() lines<0! lines=%d",lines);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x64;
	idx++;
	gCmdBuf[idx] = (unsigned char)(lines&0xff);
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBuffAndFeedLines() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBuffAndFeedLines() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBuffAndFeedLines() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：按类型实时查询打印机状态；
 * 入口参数：
 * 					type：1,查询钱箱状态；2,查询纸仓盖状态；3,查询切刀状态；4,查询缺纸状态;
					flag：端口宏
 * 出口参数：
 *					无;
 * 返回值：
 *					0:正常,1:缺纸,2:纸仓盖开,3:切刀错误,4:钱箱高电平;
 *					<0: 错误；
 *
 */
int POS_Status_RTQueryTypeStatus(int type)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((type!=1)&&(type!=2)&&(type!=3)&&(type!=4))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() type is invalid(1,2,3,4)! type=%d",type);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}
	    	
	gCmdBuf[idx] = 0x10;
	idx++;
	gCmdBuf[idx] = 0x04;
	idx++;
	gCmdBuf[idx] = (unsigned char)(type&0xff);
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	//--------------2016.12.19.ztongli--------------
	emptyAttribute(&al);
	al.cmdBuf		=	gCmdBuf;
	al.bufLen		=	gCmdBufLen;
	ret				=	writeData(&al);
	//--------------2016.12.19.ztongli--------------
	
	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -2;
	}	
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_write() success! ready read...");
	DoLog(gLogBuf,strlen(gLogBuf));

	// 读取数据；
	gRcvBufLen=1;
	memset(gRcvBuf,0,sizeof(gRcvBuf));
	//ret=Sprt_net_read(gRcvBuf,gRcvBufLen);		
	//--------------2016.12.19.ztongli--------------
	emptyAttribute(&al);
	al.cmdBuf		=	gRcvBuf;
	al.bufLen		=	gRcvBufLen;
	ret		=	readData(&al);
	//--------------2016.12.19.ztongli--------------
	if(ret<=0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() fail! ret<=0,ret=%d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		
		return -3;
	}
	
	if(ret!=1)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() fail! ret!=1,ret=%d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		
		return -4;
	}	
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() ret=%d,gRcvBuf[0]=%x",ret,gRcvBuf[0]);
	DoLog(gLogBuf,strlen(gLogBuf));

	unsigned char b=gRcvBuf[0];
	int flag=0;
	if(type==1)			// 查询钱箱状态
	{	
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() type=1");
		DoLog(gLogBuf,strlen(gLogBuf));
  	flag=b&0x12;	// 其他位不关心，仅关心这两个固定为1的位，如果不是1则不正常；
  	if(flag==0x12)
  	{
  		ret=0;
  	}
  	else
  	{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() type=1,flag=%02x",flag);
			DoLog(gLogBuf,strlen(gLogBuf));
   		return -5;
  	}
  	flag=b&0x04;
  	if(flag!=0)
  	{
  		ret=4;
  	}
	}else if(type==2){			// 查询纸仓盖状态
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() type=2");
		DoLog(gLogBuf,strlen(gLogBuf));
  	flag=b&0x12;
  	if(flag==0x12)
  	{
  		ret=0;
  	}
  	else
  	{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() type=2,flag=%02x",flag);
			DoLog(gLogBuf,strlen(gLogBuf));
   		return -6;
  	}
  	flag=b&0x04;
  	if(flag!=0)
  	{
  		ret=2;
  	}
	}else if(type==3){			// 查询切刀状态
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() type=3");
		DoLog(gLogBuf,strlen(gLogBuf));
  	flag=b&0x12;
  	if(flag==0x12)
  	{
  		ret=0;
  	}
  	else
  	{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() type=3,flag=%02x",flag);
			DoLog(gLogBuf,strlen(gLogBuf));
      return -7;
  	}
  	flag=b&0x08;
  	if(flag!=0)
  	{
  		ret=3;
  	}
 		
	}else{						// 查询缺纸状态
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() Sprt_serial_read() type=4");
		DoLog(gLogBuf,strlen(gLogBuf));
  	flag=b&0x12;
  	if(flag==0x12)
  	{
  		ret=0;
  	}
  	else
  	{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() type=4,flag=%02x",flag);
			DoLog(gLogBuf,strlen(gLogBuf));
   		return -8;
  	}
  	flag=b&0x40;
  	if(flag!=0)
  	{
  		ret=1;
  	}
	}
	
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Status_RTQueryTypeStatus() end.");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return ret;
  	
}


/* 
 * 功能：设置打印西文字体;
 * 入口参数：
					flag：端口标志
 * 					isFont：0,压缩字体(9x17)；1,正常字体(12x24);
 * 					isBold：0,正常；1,加粗;
 * 									加粗模式对字符和汉字都有效，除加粗模式外，其他模式只对字符有效。
 * 					isDoubleWidth：0,正常；1,倍宽;
 * 					isDoubleHeight：0,正常；1,倍高;
 * 					isUnderLine：0,正常；1,有下划线;
 *					
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_SetPrintFontE(int isFont,
				    									 int isBold,
				    									 int isDoubleWidth,
				    									 int isDoubleHeight,
				    									 int isUnderLine
				    								 )
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((isFont!=0)&&(isFont!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() isFont is invalid(0,1)! isFont=%d",isFont);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	  	
	if((isBold!=0)&&(isBold!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() isBold is invalid(0,1)! isBold=%d",isBold);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
	if((isDoubleWidth!=0)&&(isDoubleWidth!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() isDoubleWidth is invalid(0,1)! isDoubleWidth=%d",isDoubleWidth);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
	if((isDoubleHeight!=0)&&(isDoubleHeight!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() isDoubleHeight is invalid(0,1)! isDoubleHeight=%d",isDoubleHeight);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
	if((isUnderLine!=0)&&(isUnderLine!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() isUnderLine is invalid(0,1)! isUnderLine=%d",isUnderLine);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x21;
	idx++;
	if(isFont==0)					// 压缩字体（9*17）
	{	
		gCmdBuf[idx] |= 0x01;
	}	
	else
	{	
		gCmdBuf[idx] &= 0xfe;
	}	

	if(isBold!=0)
	{
		gCmdBuf[idx] |= 0x08;
	}	
	else 
	{
		gCmdBuf[idx] &= 0xf7;
	}

	if(isDoubleWidth!=0)
	{
		gCmdBuf[idx] |= 0x20;
	}
	else 
	{
		gCmdBuf[idx] &= 0xdf;
	}

	if(isDoubleHeight!=0)
	{	
		gCmdBuf[idx] |= 0x10;
	}	
	else 
	{
		gCmdBuf[idx] &= 0xef;
	}

	if(isUnderLine!=0)
	{
		gCmdBuf[idx] |= 0x80;
	}
	else 
	{
		gCmdBuf[idx] &= 0x7f;
	}

	idx++;
	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	
	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -2;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontE() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：设置汉字字体;
 * 入口参数：
 * 					isDoubleWidth：0,正常；1,倍宽;
 * 					isDoubleHeight：0,正常；1,倍高;
 * 					isUnderLine：0,正常；1,有下划线;
 *					
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_SetPrintFontC( int isDoubleWidth,
    									 				 int isDoubleHeight,
    									 				 int isUnderLine
				    								 )
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((isDoubleWidth!=0)&&(isDoubleWidth!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() isDoubleWidth is invalid(0,1)! isDoubleWidth=%d",isDoubleWidth);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
	if((isDoubleHeight!=0)&&(isDoubleHeight!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() isDoubleHeight is invalid(0,1)! isDoubleHeight=%d",isDoubleHeight);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
	if((isUnderLine!=0)&&(isUnderLine!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() isUnderLine is invalid(0,1)! isUnderLine=%d",isUnderLine);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1c;
	idx++;
	gCmdBuf[idx] = 0x21;
	idx++;

	if(isDoubleWidth!=0)
	{
		gCmdBuf[idx] |= 0x04;
	}
	else 
	{
		gCmdBuf[idx] &= 0xfb;
	}

	if(isDoubleHeight!=0)
	{	
		gCmdBuf[idx] |= 0x08;
	}	
	else 
	{
		gCmdBuf[idx] &= 0xf7;
	}

	if(isUnderLine!=0)
	{
		gCmdBuf[idx] |= 0x80;
	}
	else 
	{
		gCmdBuf[idx] &= 0x7f;
	}

	idx++;
	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -2;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_SetPrintFontC() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：打印二维条码;
 * 入口参数：
 * 		条码类型：  n=0 选择PDF417,n=1 选择DATA MATRIX,n=2 选择QR CODE;
 * 					v：
 *					r：
 * 					各参数含义和范围根据GS Z选择的二维码类型不同而不同。
 * 					参数v, r不同的条码，其参数含义不同。
 *					① PDF417二维条码
 *					1 ≤ v ≤ 30	表示每行字符数。不同的机型由于纸宽不同，v的最大值应该在该机型允许的最大值之内。
 *					0 ≤ r ≤ 8	表示纠错等级。
 *					② DATA MATRIX二维条码
 *					0 ≤v ≤ 144	表示图形高(0：自动选择)。
 *					8 ≤ r ≤ 144	表示图形宽(v=0时，无效)。
 *					③ QR CODE二维条码
 *					0 ≤ v ≤ 40	表示图形版本号(0：自动选择)。
 *					r =76,77,81,72	表示纠错等级(L:7%, M:15%,Q:25%,H:30%)。
 *
 * 					k：1 ≤ k ≤ 6	表示纵向放大倍数。
 * 					dataStr:表示条码数据
 *					
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Output_PrintBar2code(int iType ,
    									 int v,
    									 int r,
    									 int k,
    									 unsigned char *dataStr
    									 )
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((dataStr==NULL)||(strlen(dataStr)==0))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() dataStr is NULL or strlen(dataStr)==0!");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;	
	}
	
	if(iType==0)				// PDF417
	{
		if((v<1)||(v>30))	
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=0,v is invalid(1 ≤ v ≤ 30)! v=%d",v);
			DoLog(gLogBuf,strlen(gLogBuf));
  		return -2;	
		}
		if((r<0)||(r>8))	
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=0,r is invalid(0 ≤ r ≤ 8)! r=%d",r);
			DoLog(gLogBuf,strlen(gLogBuf));
  		return -3;	
		}
	}else if(iType==1){			// DATA MATRIX
		if((v<0)||(v>144))	
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=1,v is invalid(0 ≤v ≤ 144)! v=%d",v);
			DoLog(gLogBuf,strlen(gLogBuf));
  		return -4;	
		}
		if((r<8)||(r>144))	
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=1,r is invalid(8 ≤ r ≤ 144)! r=%d",r);
			DoLog(gLogBuf,strlen(gLogBuf));
  		return -5;	
		}
	}else if(iType==2){			// QR CODE
		if((v<0)||(v>40))	
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=2,v is invalid(0 ≤ v ≤ 40)! v=%d",v);
			DoLog(gLogBuf,strlen(gLogBuf));
  		return -6;	
		}
		if((r!=76)&&(r!=77)&&(r!=81)&&(r!=72))	
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=2,r is invalid(76,77,81,72)! r=%d",r);
			DoLog(gLogBuf,strlen(gLogBuf));
  		return -7;	
		}
		
	}else{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType is invalid(0,1,2 is correct)! iType=%d",iType);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -8;	
	}
	
	if((k<1)||(k>6))	
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() k is invalid(1 ≤ v ≤ 6)! k=%d",k);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -9;	
	}    		
	
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() iType=%d,v=%d,r=%d,dataStr=%s",iType,v,r,dataStr);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	gCmdBuf[idx]=0x1d;
	idx++;
	gCmdBuf[idx]=0x5a;
	idx++;
	gCmdBuf[idx]=(unsigned char)(iType&0xff);
	idx++;
	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x5a;
	idx++;
	gCmdBuf[idx]=(unsigned char)(v&0xff);
	idx++;
	gCmdBuf[idx]=(unsigned char)(r&0xff);
	idx++;
	gCmdBuf[idx]=(unsigned char)(k&0xff);
	idx++;

	unsigned char *dataBytes=dataStr;
	int dataBytesLength=strlen(dataStr);
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() dataBytesLength=%d,dataBytes=%s",dataBytesLength,dataBytes);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	gCmdBuf[idx]=(unsigned char)(dataBytesLength&0xff);
	idx++;
	gCmdBuf[idx]=(unsigned char)((dataBytesLength>>8)&0xff);
	idx++;

	int i=0;
	for(i=0; i<dataBytesLength; i++)
	{
		gCmdBuf[idx]=dataBytes[i];
		idx++;
	}
	
	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -2;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar2code() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：控制钱箱 ESC p m t1 t2;
 * 入口参数：
 * 					m：钱箱号 0 表示钱箱输出插座引脚2， 1 表示钱箱输出插座引脚5;
 * 					t1：脉冲开启的时间为 [ t1 × 2 ms];
 * 					t2：脉冲关闭的时间为 [ t2 × 2 ms];
 * 			  			读入t1、t2,确定本次开钱箱的脉冲宽度;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_CashDraw(int m,int t1,int t2)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((m!=0)&&(m!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() m is invalid(0,1)! m=%d",m);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	
	if(t1<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() t1<0! t1=%d",t1);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -2;
	}	    	
	if(t2<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() t2<0! t2=%d",t2);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -3;
	}	    	

	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x70;
	idx++;
	gCmdBuf[idx] = (unsigned char)(m&0xff);
	idx++;
	gCmdBuf[idx] = (unsigned char)(t1&0xff);
	idx++;
	gCmdBuf[idx] = (unsigned char)(t2&0xff);
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_CashDraw() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：选择/取消黑白反显打印模式;
 * 入口参数：
 * 					n：0 取消反显打印,1 选择反显打印;
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Control_OppositeColor(int n)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_OppositeColor() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((n!=0)&&(n!=1))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_OppositeColor() n is invalid(0,1)! n=%d",n);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	    	

	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x42;
	idx++;
	gCmdBuf[idx] = (unsigned char)(n&0xff);
	idx++;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_OppositeColor() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_OppositeColor() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Control_OppositeColor() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：一维条码打印;
 * 入口参数：
 * 			m：条码类型，0 ≤ m ≤ 6 或65 ≤ m ≤ 73 ,详见打印机说明书;
 * 			w：宽度,条码的横向模块宽度：2 ≤ w ≤ 6 对应不同的mm,如：2对应0.25，6对应0.75
 * 			h：高度, 条码纵向点数;
 *			n：文字位置; 0 不打印,1 在条码上方打印,2 在条码下方打印,3 条码上、下方都打印;
 * 			hriTextStr：文本信息;
 * 出口参数：
 *			无;
 * 返回值：
 *			0: 正常;
 *			<0: 错误；
 *
 */
int POS_Output_PrintBar1code(int m,int w,int h,int n,unsigned char  *hriTextStr)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((n!=0)&&(n!=1)&&(n!=2)&&(n!=3))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() n is invalid! n=%d",n);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	    	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() m=%d,w=%d,h=%d,n=%d,hriTextStr=%s",m,w,h,n,hriTextStr);
	DoLog(gLogBuf,strlen(gLogBuf));
    
	//发GS W n设置宽度
	gCmdBuf[idx]=0x1d;
	idx++;
	gCmdBuf[idx]=0x77;
	idx++;
	gCmdBuf[idx]=(unsigned char)(w&0xff);
	idx++;
    
    //发GS h n设置高度
	gCmdBuf[idx]=0x1d;
	idx++;
	gCmdBuf[idx]=0x68;
	idx++;
	gCmdBuf[idx]=(unsigned char)(h&0xff);
	idx++;
    
    //发GS H n设置文字位置
	gCmdBuf[idx]=0x1d;
	idx++;
	gCmdBuf[idx]=0x48;
	idx++;
	gCmdBuf[idx]=(unsigned char)(n&0xff);
	idx++;

	unsigned char  *hriTextStrBytes=hriTextStr;
	int len=strlen(hriTextStrBytes);

	if((m>=0)&&(m<=6))
	{
        //发GS k m d1...dk nul打印
	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x6b;
	idx++;
	gCmdBuf[idx] = (unsigned char)(m&0xff);
	idx++;
	
	memcpy((unsigned char *)&gCmdBuf[idx],hriTextStrBytes,len);
	idx+=len;
	
	gCmdBuf[idx]=0x00;
	idx++;
	
	}else if((m>=65)&&(m<=73)){
		//发GS k m n d1...dn打印
		gCmdBuf[idx] = 0x1d;
		idx++;
		gCmdBuf[idx] = 0x6b;
		idx++;
		gCmdBuf[idx] = (unsigned char)(m&0xff);
		idx++;
		gCmdBuf[idx] = (unsigned char)(len&0xff);;
		idx++;
		memcpy((unsigned char *)&gCmdBuf[idx],hriTextStrBytes,len);
		idx+=len;
	
	}else{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() m is invalid(0-6,65-73)! m=%d",m);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -2;	
	}

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -3;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBar1code() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：打印一行黑白位图，后面必须再发送回车换行才能打印;
 * 入口参数：
 * 		m:位图模式,0:8点单密度, 1: 8点双密度,32:24点单密度, 33:24点双密度;可选择固定为0；
 * 		n：指令要求位图数据长度(纵向排列，一行一行打印);是横向的点数；如8点就是如果10个字节就是10，如果是24点就是如果是30个字节就是10;
 * 		bytes：位图数据;
 *		bmpByteLength:位图数据字节数；
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Output_PrintBitGraph(int m,int n,unsigned char *bmpByte,int bmpByteLength)
{
	int idx=0;
	int ret=-1;
	
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBitGraph() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((m!=0)&&(m!=1)&&(m!=32)&&(m!=33))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBitGraph() m is invalid(0,1,32,33)! m=%d",m);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	    	
	if(n<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBitGraph() n<0! n=%d",n);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -2;
	}	    	    	
	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x2a;
	idx++;
	gCmdBuf[idx] = (unsigned char)(m&0xff);
	idx++;
	gCmdBuf[idx] = (unsigned char)(n&0xff);
	idx++;
	gCmdBuf[idx] = (unsigned char)((n>>8)&0xff);
	idx++;
	
	memcpy((unsigned char *)&gCmdBuf[idx],bmpByte,bmpByteLength);
	idx+=bmpByteLength;

	gCmdBufLen=idx;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBitGraph() ready Sprt_serial_write(),gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	gCmdBuf;
	al.bufLen			=	gCmdBufLen;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------
	//ret=Sprt_net_write(gCmdBuf,gCmdBufLen);

	if(ret!=gCmdBufLen)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBitGraph() Sprt_serial_write() fail! ret=%d,gCmdBuf[]=0x%02x,0x%02x,gCmdBufLen=%d",ret,gCmdBuf[0],gCmdBuf[1],gCmdBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -2;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBitGraph() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：打印用户磁盘上的图像文件；
 * 入口参数：

 *					imagePath: 图像文件路径（若只有文件名则使用当前路径，若指定全路径则使用指定的路径）; 
 * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0:其他错误；
 * 说明：
 *					根据指定的文件路径读取文件，解析出图像信息并打印;
 *					仅支持单色位图文件;
 *					
 */
int POS_Output_PrintBmpDirect(unsigned char *imagePath)
{

	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBmpDirect() imagePath=%s",imagePath);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	ret=InitBmpFile(imagePath);
	if( ret!=0 )
	{
		if(m_lpBuffer!=NULL)
		{
			free(m_lpBuffer);
			m_lpBuffer=NULL;
		}	

		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBmpDirect() InitBmpFile() fail! ret=%d,imagePath=%s",ret,imagePath);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -1;
		
	}	
	
	char *pszBuffer=NULL;
	int bufLen=MakeCmdBuffer(&pszBuffer);
	if(bufLen<=0)
	{
		if(pszBuffer!=NULL)
		{
			free(pszBuffer);
			pszBuffer=NULL;
		}	
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBmpDirect() MakeCmdBuffer() fail! bufLen=%d",bufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -2;
	}		
	
	//---------2016.12.20.ztongli---------
	emptyAttribute(&al);
	al.cmdBuf			=	pszBuffer;
	al.bufLen			=	bufLen;
	ret					=	writeData(&al);
	//---------2016.12.20.ztongli---------
	//ret=Sprt_net_write(pszBuffer,bufLen);
	if(ret!=bufLen)
	{
		if(m_lpBuffer!=NULL)
		{
			free(m_lpBuffer);
			m_lpBuffer=NULL;
		}	
		if(pszBuffer!=NULL)
		{
			free(pszBuffer);
			pszBuffer=NULL;
		}	

		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBmpDirect() Sprt_serial_write() fail! ret=%d,bufLen=%d",ret,bufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -3;
	}	

	if(m_lpBuffer!=NULL)
	{
		free(m_lpBuffer);
		m_lpBuffer=NULL;
	}	
	if(pszBuffer!=NULL)
	{
		free(pszBuffer);
		pszBuffer=NULL;
	}	


	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintBmpDirect() Sprt_serial_write() Success! ");
	DoLog(gLogBuf,strlen(gLogBuf));

	return 0;	
		
}

/* 
 * 功能：发送给打印机一行字符串;
 * 入口参数：
 * 		printText:字符串以'\0'结尾；注意需以回车换行字符为结束才能立即打印；
  * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Output_PrintString(unsigned char *printText)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((printText==NULL)||(strlen(printText)==0))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() (printText==NULL)||(strlen(printText)==0)!");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	    		

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() ready Sprt_serial_write(),printText=%s",printText);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	int len=strlen(printText);
	//ret=Sprt_net_write(printText,len);

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	printText;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	if(ret!=len)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() Sprt_serial_write() fail! ret=%d,len=%d",ret,len);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -3;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}

/* 
 * 功能：发送给打印机字节数组;
 * 入口参数：
 * 		printByte:字节数组；
 *    printByteSize:字节数组大小；
  * 出口参数：
 *					无;
 * 返回值：
 *					0: 正常;
 *					<0: 错误；
 *
 */
int POS_Output_PrintData(unsigned char *printByte, int printByteSize)
{
	int idx=0;
	int ret=-1;
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintData() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if((printByte==NULL))
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintData() (printByte==NULL)!");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}	    	    	
	if(printByteSize<=0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintData() printByteSize<=0! printByteSize=%d",printByteSize);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -2;
	}	    	    	
	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() ready Sprt_serial_write(),printByte[0]=%02x",printByte[0]);
	DoLog(gLogBuf,strlen(gLogBuf));
	

	//-----------ztongli.2016.12.19-------------
	emptyAttribute(&al);
	al.cmdBuf			=	printByte;
	al.bufLen			=	printByteSize;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.19-------------

	//ret=Sprt_net_write(printByte,printByteSize);
	if(ret!=printByteSize)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() Sprt_serial_write() fail! ret=%d,printByteSize=%d",ret,printByteSize);
		DoLog(gLogBuf,strlen(gLogBuf));

		return -3;
	}	

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c POS_Output_PrintString() Sprt_serial_write() Success!");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return 0;	
  	
}
////////////////////////////////////WX_20160908,begin////////////////////////////////////

////////////////////////////////////ESC/POS////////////////////////////////////
/*
	* 功能：旋转打印
	* 入口参数：n(0,不旋转；1,旋转)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Control_SetRotaryPrint(int n)
{
	int idx = 0;
	int ret = -1;
	
	if(n<0)
	{
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x56;
	idx++;
	gCmdBuf[idx] = (unsigned char)(n&0xff);
	idx++;

	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：倒置打印
	* 入口参数：n(0,不倒置打印；1,倒置打印)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Control_SetInvertedPrint(int n)
{
	int idx = 0;
	int ret = -1;
	
	if(n<0)
	{
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x7b;
	idx++;
	gCmdBuf[idx] = (unsigned char)(n&0xff);
	idx++;

	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印预下载位图
	* 入口参数：n(位图号:0——7)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Output_PrintFlashBmp(int n)
{
	int idx = 0;
	int ret = -1;
	
	if(n<0)
	{
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1c;
	idx++;
	gCmdBuf[idx] = 0x50;
	idx++;
	gCmdBuf[idx] = (unsigned char)(n&0xff);
	idx++;

	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印测试页
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Control_PrintTestpage()
{
	int idx = 0;
	int ret = -1;
  	
	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x28;
	idx++;
	gCmdBuf[idx] = 0x41;
	idx++;
	gCmdBuf[idx] = 0x02;
	idx++;
	gCmdBuf[idx] = 0x00;
	idx++;
	gCmdBuf[idx] = 0x00;
	idx++;
	gCmdBuf[idx] = 0x02;
	idx++;
	
	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置行高
	* 入口参数：n(行高)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Control_SetLineSpace(int n)
{
	int idx = 0;
	int ret = -1;
	
	if(n<0)
	{
		return -1;
	}	    	
  	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x33;
	idx++;
	gCmdBuf[idx] = (unsigned char)(n&0xff);
	idx++;

	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：黑标定位
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Control_BlackMark()
{
	int idx = 0;
	int ret = -1;
  	
	gCmdBuf[idx] = 0x0c;
	idx++;
	
	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：打印本地文档
	* 入口参数：lpFilePath(本地文档路径)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Output_SendLocalFile(unsigned char *lpFilePath)
{
	
	
}

/*
	* 功能：查询打印任务状态
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Status_QueryTaskStatus()
{
	int idx = 0;
	int ret = -1;
  	
	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x28;
	idx++;
	gCmdBuf[idx] = 0x48;
	idx++;
	gCmdBuf[idx] = 0x06;
	idx++;
	gCmdBuf[idx] = 0x00;
	idx++;
	gCmdBuf[idx] = 0x30;
	idx++;
	gCmdBuf[idx] = 0x30;
	idx++;
	gCmdBuf[idx] = 0x31;
	idx++;
	gCmdBuf[idx] = 0x32;
	idx++;
	gCmdBuf[idx] = 0x33;
	idx++;
	gCmdBuf[idx] = 0x34;
	idx++;
	
	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：查询打印机ID号
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int POS_Input_PrinterId(char *buf)
{
	int idx = 0;
	int ret = -1;
  	
	gCmdBuf[idx] = 0x1d;
	idx++;
	gCmdBuf[idx] = 0x49;
	idx++;
	gCmdBuf[idx] = 0x42;
	idx++;

	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -1;
	}	
	
	return 0;	
	
}

////////////////////////////////////ESC/POS////////////////////////////////////

/////////////////////////////////////CPCL//////////////////////////////////////
/*
	* 功能：打印
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_Print()
{
	int ret = -1;
		
	char *p="PRINT\r\n";
	int len=strlen(p);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	p;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(p,len,10);
	//ret=Sprt_net_write(p,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：找缝隙
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_Form()
{
	int ret = -1;
	
	char *p="FORM\r\n";
	int len=strlen(p);
	//ret=Sprt_usb_write(p,len,10);
	ret=Sprt_net_write(p,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印PDF417
	* 入口参数：
*			x:条码水平方向起始位置;
*			y:条码垂直方向起始位置;
*			XDn: 最小单元横向宽度，范围：1到32，默认：2.
*			YDn: 最小单元纵向高度，范围：1到32，默认：6
*			Cn:每行字符数。范围：1到30，默认：3
*			Sn:纠错等级。范围：1到8，默认：1;
*			data: 条码数据;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_Draw2Barcode_PDF417(int x, int y, int XDn, int YDn, int Cn, int Sn, char *data)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (XDn < 1 || XDn > 32) 
	{
		return -1;
	}
	
	if (YDn < 1 || YDn > 32) 
	{
		return -1;
	}
	
	if (Cn < 1 || Cn > 30) 
	{
		return -1;
	}
	
	if (Sn < 1 || Sn > 8) 
	{
		return -1;
	}
	
	sprintf(Buf,"BARCODE PDF-417 %d %d XD %d YD %d C %d S %d %s\r\nENDPDF\r\n",x,y,XDn,YDn,Cn,Sn,data);
	
	int len=strlen(Buf);
	
	//ret=Sprt_usb_write(Buf,len,10);
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：打印QR二维码
	* 入口参数：
*			x:条码水平方向起始位置;
*			y:条码垂直方向起始位置;
*			Mn: QR条码模式.n范围：1或者2，默认：2
*			Un: 放大倍数.n范围：1到6，默认：6
*			Sn:纠错等级:
*				H-超高可靠性等级(Level H)
*				Q-高可靠性等级(Level Q)
*				M-标准等级(Level M)
*				L-高密度等级(Level L)
*			data: 条码数据;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_Draw2Barcode_QR(int x, int y, int Mn, int Un, char *Sn, char *data)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (Mn != 1 && Mn != 2) 
	{
		return -1;
	}
	
	if (Un < 1 || Un > 6) 
	{
		return -1;
	}
	
	sprintf(Buf,"BARCODE QR %d %d M %d U %d\r\n%sA,%s\r\nENDQR\r\n",x,y,Mn,Un,Sn,data);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印条码
	* 入口参数：
*      value: 0:打印横向条码,1:打印纵向条码;
*       type:条码类型，一维条码的类型有:
*				Type值	条码类型
*				UPCA	UPC-A
*				UPCE	UPC-E
*				EAN13	JAN13 (EAN13)
*				EAN8	JAN 8 (EAN8)
*				39		CODE39
*				CODABAR	CODABAR
*				93		CODE93
*				128		CODE128(Auto)
*			width: 条码窄条宽宽度.
*			ratio: 宽条宽和窄条宽比率,范围：0 —— 30
*			height:条码高度
*			x:条码水平方向起始位置;
*			y:条码垂直方向起始位置;
*			data: 条码数据;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_DrawBarcode(int value,char *type,int width,int ratio,int height,int x, int y, char *data)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (value != 0 && value != 1) 
	{
		return -1;
	}
	
	if (ratio < 0 || ratio > 30) 
	{
		return -1;
	}
	
	if (value == 0)
	{
        sprintf(Buf,"BARCODE %s %d %d %d %d %d %s\r\n",type,width,ratio,height,x,y,data);
	} 
	else if (value == 1)
	{
        sprintf(Buf,"VBARCODE %s %d %d %d %d %d %s\r\n",type,width,ratio,height,x,y,data);
	}
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：图框命令
	* 入口参数：
*			x0:顶部左角X坐标;
*			y0:顶部左角Y坐标;
*			x1: 底部右角X坐标
*			y1: 底部右角Y坐标
*			width:图框宽度
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_DrawBox(int x0,int y0,int x1,int y1,int width)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x0 < 0 || y0 < 0) 
	{
		return -1;
	}
	
	if (x1 < 0 || y1 < 0) 
	{
		return -1;
	}

	if (width < 0) 
	{
		return -1;
	}


	sprintf(Buf,"BOX %d %d %d %d %d\r\n",x0,y0,x1,y1,width);
	
	int len=strlen(Buf);
	
	//ret=Sprt_usb_write(Buf,len,10);
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：画线命令
	* 入口参数：
*     x0::左上角的横（x）坐标;
*			y0:左上角的纵（y）坐标;
*			x1:右上角水平的横（x）坐标
*			y1:右上角水平的纵（y）坐标
*			width:线条宽度
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_DrawLine(int x0,int y0,int x1,int y1,int width)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x0 < 0 || y0 < 0) 
	{
		return -1;
	}
	
	if (x1 < 0 || y1 < 0) 
	{
		return -1;
	}

	if (width < 0) 
	{
		return -1;
	}

	sprintf(Buf,"LINE %d %d %d %d %d\r\n",x0,y0,x1,y1,width);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：文本命令
	* 入口参数：
*           value: 0:水平,1:逆时针旋转90°,2:逆时针旋转180°,3:逆时针旋转270°;
*           font:选择字体号:
*				24:字符(12*24)，汉字(24*24);
*				55:字符(8*16)，汉字(16*16)
*			size:	字符高度选择	字符宽度选择
*					size	纵向放大	size	横向放大
*					0		1（正常）	0		1 （正常）
*					1		2（2倍高）	10		2 （2倍宽）
*					2		3			20		3
*					3		4			30		4
*					4		5			40		5
*					5		6			50		6
*					6		7			60		7
*					7		8			70		8
*			x:水平打印起始位置;
*			y:垂直打印起始位置
*			data:打印的文本内容
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_DrawText(int value,int font,int size,int x,int y,char *data)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (value < 0 || value > 3) 
	{
		return -1;
	}
	
	if (size < 0 || size > 7) 
	{
		return -1;
	}

	if (value == 0)
	{
        sprintf(Buf,"TEXT %d %d %d %d %s\r\n",font,size,x,y,data);
	} 
	else if (value == 1)
	{
        sprintf(Buf,"VTEXT %d %d %d %d %s\r\n",font,size,x,y,data);
	}
	else if (value == 2)
	{
        sprintf(Buf,"TEXT180 %d %d %d %d %s\r\n",font,size,x,y,data);
	}
	else if (value == 3)
	{
        sprintf(Buf,"TEXT270 %d %d %d %d %s\r\n",font,size,x,y,data);
	}
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：反显区域(以画线的方式，线所经过的区域取反处理)
	* 入口参数：
*			x0:左上角X坐标;
*			y0:左上角Y坐标;
*			x1: 右上角的水平X坐标
*			y1: 右上角的水平Y坐标
*			width:反显内容宽度
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_InverseLine(int x0,int y0,int x1,int y1,int width)
{
	int ret = -1;
	unsigned char Buf[256]={0};

	if (x0 < 0 || y0 < 0) 
	{
		return -1;
	}
	
	if (x1 < 0 || y1 < 0) 
	{
		return -1;
	}
	
	if (width < 0) 
	{
		return -1;
	}
	
	sprintf(Buf,"IL %d %d %d %d %d\r\n",x0,y0,x1,y1,width);
	
	int len=strlen(Buf);
	
	//ret=Sprt_usb_write(Buf,len,10);
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置标签大小等参数
	* 入口参数：
*           offset: 相对机头零点的偏移量；
*           height: 标签最大高度，点为单位;
*			        qty:打印标签的数量;
*           width: 标签最大宽度，点为单位，目前缺省576点即72毫米；通常不用设置，"0"为不设置，
*					但如果需要旋转，即调用：labelPrn_setPageRoate()函数，则必须设置该参数，否则旋转不起作用；
*
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_PageSetup(int offset,int height,int qty, int width)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (offset < 0) 
	{
		return -2;
	}
	
	if (height < 0) 
	{
		return -3;
	}
	
	if (qty < 0) 
	{
		return -4;
	}
	
	if (width < 0) 
	{
		return -5;
	}
	
	if(width == 0)
	{
		sprintf(Buf,"! %d 200 200 %d %d\r\n",offset,height,qty);
	}
	else
	{
		sprintf(Buf,"! %d 200 200 %d %d\r\nPW %d\r\n",offset,height,qty,width);	
	}
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置当前行内容对齐方式
	* 入口参数：
*			align:0：居左，1：居中，2：居右;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetAlign(int align)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (align < 0 || align > 2) 
	{
		return -1;
	}
	
	
	char *p=NULL;
	
	if(align==0){
		p = "LEFT\r\n";
	}else if(align==1){
		p = "CENTER\r\n";
	}else{
		p = "RIGHT\r\n";
	}
	
	int len=strlen(p);
	
	//ret=Sprt_usb_write(p,len,10);
	ret=Sprt_net_write(p,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置字体加粗
	* 入口参数：
*			value:1:加粗,0:取消;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetBold(int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (value != 0 && value != 1) 
	{
		return -1;
	}

	sprintf(Buf,"SETBOLD %d\r\n",value);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：HRI字符命令（设置一维条码文字自动打印）
	* 入口参数：
*   offset:HRI字符与条码的上下相对位移;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetHRI(char *offset)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(offset=="OFF")
	{	
		sprintf(Buf,"BARCODE-TEXT OFF\r\n");
	}else{
		sprintf(Buf,"BARCODE-TEXT 24 0 %s\r\n",offset);
	}
	
	int len=strlen(Buf);
	
	//ret=Sprt_usb_write(Buf,len,10);
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置反白显示字符
	* 入口参数：
*			value:表示是否反白显示字符,1：反白显示,0：取消反白显示;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetInverseText(int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};

	if (value != 0 && value != 1) 
	{
		return -1;
	}
	
	sprintf(Buf,"INVERSE-TEXT %d\r\n",value);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：整页顺时针旋转90°命令；调用labelPrn_pageSetup()函数，需设置宽度参数，否则不起作用
	* 入口参数：
*			value:1：旋转，0：不旋转;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetPageRoate(int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (value != 0 && value != 1) 
	{
		return -1;
	}
	//memset(Buf,0,sizeof(Buf));
	sprintf(Buf,"PR %d\r\n",value);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置字符/汉字间距
	* 入口参数：
*			spacing:字符之间的距离，默认字符间距是0;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetSpaceing(int spacing)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (spacing < 0) 
	{
		return -1;
	}

	sprintf(Buf,"SETSP %d\r\n",spacing);
	
	int len=strlen(Buf);
	
	//ret=Sprt_usb_write(Buf,len,10);
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置是否打印下划线
	* 入口参数：
*			value:1：打印1点下划线，2：打印2点下划线，0：取消打印下划线;
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_SetUnderLineText(int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (value < 0 || value > 2) 
	{
		return -1;
	}
	
	sprintf(Buf,"UT %d\r\n",value);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(Buf,len,10);
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印单色位图
	* 入口参数：
*			type:0:打印扩展图形,1:打印压缩图形
*			x: 水平起始位置
*			y:垂直起始位置
*			lpFilePath:图片路径和文件名
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int CPCL_PrintBMP(int type,int x,int y,char *lpFilePath)
{
	unsigned long	dwRes	= 0;
	long	iRet	= 0;
	int	pathSizeT = sizeof(lpFilePath);
	int retBytesSize = 0;
	int xPos = x;
    int yPos = y;
	if(pathSizeT<=0)
	{
		return -1;
	}
	if((xPos<0)||(yPos<0))
	{
		return -1;
	}

	sprintf(gLogBuf,"CPCL bmp print begin!!!");
	DoLog(gLogBuf,strlen(gLogBuf));

	FILE *hFile = NULL;
	hFile=fopen(lpFilePath,"rb");
	if(hFile==NULL)
	{
		return -1;
	}		

	unsigned char szBuff[256] = {0};
	BITMAPFILEHEADER bmfh;
	int ret=fread(szBuff,1,sizeof(BITMAPFILEHEADER),hFile);
	bmfh.bfType = (szBuff[0]<<8)|szBuff[1];
	bmfh.bfSize = szBuff[5]<<32|szBuff[4]<<16|szBuff[3]<<8|szBuff[2];
	bmfh.bfReserved1 = (szBuff[7]<<8)|szBuff[6];
	bmfh.bfReserved2 = (szBuff[9]<<8)|szBuff[8];
	bmfh.bfOffBits = szBuff[13]<<32|szBuff[12]<<16|szBuff[11]<<8|szBuff[10];

	sprintf(gLogBuf,"bmfh->bfType=%x,bmfh->bfSize=%x,bmfh->bfReserved1=%x,bmfh->bfReserved2=%x,bmfh->bfOffBits=%x",bmfh.bfType,bmfh.bfSize,bmfh.bfReserved1,bmfh.bfReserved2,bmfh.bfOffBits);
	DoLog(gLogBuf,strlen(gLogBuf));

	long dataOffset=0;
	if(ret==sizeof(BITMAPFILEHEADER))
	{
		if ((szBuff[0]!=0x42)&&(szBuff[0]!=0x4d))
		{
			return -1;
		}
		dataOffset=bmfh.bfOffBits;
	}
	else
	{
		return -1;
	}
	BITMAPINFOHEADER bmf;
	ret=fread(szBuff,1,sizeof(BITMAPINFOHEADER),hFile);
	bmf.biSize = szBuff[3]<<32|szBuff[2]<<16|szBuff[1]<<8|szBuff[0];
	bmf.biWidth = szBuff[7]<<32|szBuff[6]<<16|szBuff[5]<<8|szBuff[4];
	bmf.biHeight = szBuff[11]<<32|szBuff[10]<<16|szBuff[9]<<8|szBuff[8];
	bmf.biPlanes = (szBuff[13]<<8)|szBuff[12];
	bmf.biBitCount = (szBuff[15]<<8)|szBuff[14];
	bmf.biCompression = szBuff[19]<<32|szBuff[18]<<16|szBuff[17]<<8|szBuff[16];
	bmf.biSizeImage = szBuff[23]<<32|szBuff[22]<<16|szBuff[21]<<8|szBuff[20];
	bmf.biXPelsPerMeter = szBuff[27]<<32|szBuff[26]<<16|szBuff[25]<<8|szBuff[24];
	bmf.biYPelsPerMeter = szBuff[31]<<32|szBuff[30]<<16|szBuff[29]<<8|szBuff[28];
	bmf.biClrUsed = szBuff[35]<<32|szBuff[34]<<16|szBuff[33]<<8|szBuff[32];
	bmf.biClrImportant = szBuff[39]<<32|szBuff[38]<<16|szBuff[37]<<8|szBuff[36];

	sprintf(gLogBuf,"bmf->biSize=%x,bmf->biWidth=%x,bmf->biHeight=%x,bmf->biPlanes=%x,bmf->biBitCount=%x,bmf->biCompression=%x,bmf->biSizeImage=%x,bmf->biXPelsPerMeter=%x,bmf->biYPelsPerMeter=%x,bmf->biClrUsed=%x,bmf->biClrImportant=%x",bmf.biSize,bmf.biWidth,bmf.biHeight,bmf.biPlanes,bmf.biBitCount,bmf.biCompression,bmf.biSizeImage,bmf.biXPelsPerMeter,bmf.biYPelsPerMeter,bmf.biClrUsed,bmf.biClrImportant);
	DoLog(gLogBuf,strlen(gLogBuf));


	sprintf(gLogBuf,"BITMAPFILEHEADER=%d,BITMAPINFOHEADER=%d,RGBQUAD=%d",sizeof(BITMAPFILEHEADER),sizeof(BITMAPINFOHEADER),sizeof(RGBQUAD));
	DoLog(gLogBuf,strlen(gLogBuf));



	int width=0;
	int height=0;
	if(ret==sizeof(BITMAPINFOHEADER))
	{
		width = bmf.biWidth;
		height = bmf.biHeight;
		sprintf(gLogBuf,"width=%x,height=%x",width,height);
		DoLog(gLogBuf,strlen(gLogBuf));
	}
	else
	{
		return -1;
	}

	int dataLen = bmfh.bfSize - (sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+2*sizeof(RGBQUAD));

	sprintf(gLogBuf,"dataLen=%d,bmfh.bfSize=%x,dataOffset=%d",dataLen,bmfh.bfSize,dataOffset);
	DoLog(gLogBuf,strlen(gLogBuf));

	ret=fseek(hFile,dataOffset,SEEK_SET);
	if(ret!=0)
	{
		return -1;
	}	

	int iRealWidth  = (width+31)/32;
	iRealWidth *= 32;	
	int iRealWidthByte=iRealWidth/8;

	sprintf(gLogBuf,"iRealWidth=%d,iRealWidthByte=%d",iRealWidth,iRealWidthByte);
	DoLog(gLogBuf,strlen(gLogBuf));


	char *retBytes	= NULL;
	retBytes =(char *)malloc(dataLen+256);
    memset(retBytes, 0, dataLen+256);

	char *lpBuffer	= NULL;
	lpBuffer =(char *)malloc(dataLen+256);
	memset(lpBuffer, 0, dataLen+256);

	ret=fread((char *)lpBuffer,1,dataLen,hFile);

	if(ret!=dataLen)
	{
		return -1;
	}
	fclose(hFile);

	int cmdLen=0;
	if(type==0)
	{
		sprintf((char *)retBytes,"EG %d %d %d %d ",iRealWidthByte,height,xPos,yPos);
	}
	else
	{
		sprintf((char *)retBytes,"CG %d %d %d %d ",iRealWidthByte,height,xPos,yPos);
	}
	cmdLen=strlen((char *)retBytes);

	sprintf(gLogBuf,"cmdLen=%d",cmdLen);
	DoLog(gLogBuf,strlen(gLogBuf));

	

	int i=0;
	if( (width%32 != 0) )		
	{
		long orgByte = width/8;
		long orgBits = width%8;
		int tv		 = 0;
		long padByte = (iRealWidth-width)/8;		
		for(i=0; i<height; i++)
		{
			if(orgBits)		
			{
				lpBuffer[iRealWidthByte*i+orgByte] |= 0xff>>orgBits;
			}
			tv = iRealWidthByte*i+orgByte+1;
			memset(lpBuffer+tv, 0xff, padByte); 
		}
	}

	int m=0;
	int n=0;
	for(m=0; m<height; m++)
	{
		for(n=0; n<iRealWidthByte; n++)
		{
			lpBuffer[m*iRealWidthByte+n]=~lpBuffer[m*iRealWidthByte+n];
		}
	}	
 
	/*int tt;
	for(tt = 0 ; tt < dataLen; tt++)
	{
	   sprintf(gLogBuf,"%X",lpBuffer[tt]);
       DoLog(gLogBuf,1);
	}*/
    
	for(i=height-1; i>=0; --i)
	{
		//memcpy(retBytes+cmdLen+( (height-i-1) * iRealWidthByte ), lpBuffer+(i*iRealWidthByte), iRealWidthByte);
		memcpy(retBytes+cmdLen+( (height-i-1) * iRealWidthByte ), lpBuffer+(i*iRealWidthByte), iRealWidthByte);
	}


	free(lpBuffer);

	retBytes[cmdLen+dataLen]=0x0d;
	retBytes[cmdLen+dataLen+1]=0x0a;


	retBytesSize=cmdLen+dataLen+2;

	int t;
	for(t = 0 ; t < retBytesSize; t++)
	{
	   sprintf(gLogBuf,"%X",retBytes[t]);
       DoLog(gLogBuf,4);
	}

//-----------ztongli.2016.12.21-------------
	emptyAttribute(&al);
	al.cmdBuf			=	retBytes;
	al.bufLen			=	retBytesSize;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.21-------------
	
	//ret=Sprt_usb_write(retBytes,retBytesSize,100);
	//ret=Sprt_net_write(retBytes,retBytesSize);
	if(ret!=retBytesSize)
	{
		return -1;
	}	
	free(retBytes);
	return 0;	
}
/////////////////////////////////////CPCL//////////////////////////////////////

/////////////////////////////////////TSPL//////////////////////////////////////
/*
	* 功能：清除缓冲区内容
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_CLS()
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	sprintf(Buf,"CLS\r\n");
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置标签纸宽度和高度
	* 入口参数：
*			pageWidth: 标签纸宽度
*			pageHeight:标签纸高度
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_PageSetup(int pageWidth,int pageHeight)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (pageWidth < 0 || pageHeight < 0) 
	{
		return -1;
	}
	
	sprintf(Buf,"SIZE %d mm,%d mm\r\n",pageWidth,pageHeight);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：画线
	* 入口参数：
*			x:左上角水平方向起点，以点（dot）表示(不可超过标签宽度)
*			y:左上角垂直方向起点，以点（dot）表示(不可超过标签高度)
			lineLength:线宽，以点（dot）表示
			lineHeight:线高，以点（dot）表示 
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_DrawLine(int x, int y, int lineLength, int lineHeight)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (lineLength < 0 || lineHeight < 0) 
	{
		return -1;
	}
	
	sprintf(Buf,"BAR %d,%d,%d,%d\r\n",x,y,lineLength,lineHeight);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印矩形框体
	* 入口参数：
				x_start:矩形水平方向左上角x起始位置以点（dot）表示
				y_start:矩形垂直方向左上角y起始位置以点（dot）表示
				x_end:矩形水平方向右下角x结束位置以点（dot）表示
				y_end:矩形垂直方向右下角y结束位置以点（dot）表示
				Linethickness:矩形线宽，以点（dot）表示
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_DrawBorder(int x_start, int y_start, int x_end, int y_end, int Linethickness)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x_start < 0 || y_start < 0) 
	{
		return -1;
	}
	
	if (x_end < 0 || y_end < 0) 
	{
		return -1;
	}
	
	if (Linethickness < 0) 
	{
		return -1;
	}
	
	sprintf(Buf,"BOX %d,%d,%d,%d,%d\r\n",x_start,y_start,x_end,y_end,Linethickness);
	
	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：画圆
	* 入口参数：
				x:圆心X坐标(dot)		
				y:圆心Y坐标(dot)
				diameter:圆的直径大小(dot)
				thickness:圆线的宽度(dot)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_DrawCircle(int x, int y, int diameter, int thickness)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (diameter < 0 || thickness < 0) 
	{
		return -1;
	}
	
	sprintf(Buf,"CIRCLE %d,%d,%d,%d\r\n",x,y,diameter,thickness);
	
	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印文字
	* 入口参数：
				x:文字 X 方向起始点坐标(dot)		
				y:文字 Y 方向起始点坐标(dot)
				font:0(简体中文 24×24Font),1(繁体中文 24×24Font)
				rotation:文字旋转角度（顺时针方向）
								0            0度
								90          90 度
								180         180 度
								270         270 度
				xMultiplication:X 方向放大倍率 1——4
				yMultiplication:Y 方向放大倍率 1——4
				content:要打印的文字内容
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_PrintText(int x, int y, int font, int rotation, int xMultiplication, int yMultiplication, char *content)
{
	int ret = -1;
	unsigned char Buf[256]={0};

	if (x < 0 || y < 0) 
	{
		return -2;
	}
	
	if (font != 0 && font != 1) 
	{
		return -3;
	}
	
	if (rotation != 0 && rotation != 90 && rotation != 180 && rotation != 270) 
	{
		return -4;
	}
	
	if (xMultiplication < 1 || xMultiplication > 4) 
	{
		return -5;
	}
	
	if (yMultiplication < 1 || yMultiplication > 4) 
	{
		return -6;
	}
	
	if(font==0)
	{	
		sprintf(Buf,"TEXT %d,%d,\"TSS24.BF2\",%d,%d,%d,\"%s\"\r\n",x,y,rotation,xMultiplication,yMultiplication,content);
	}else{
		sprintf(Buf,"TEXT %d,%d,\"TST24.BF2\",%d,%d,%d,\"%s\"\r\n",x,y,rotation,xMultiplication,yMultiplication,content);
	}
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印一维码
	* 入口参数：
				x:欲绘制条码的水平坐标左上角起点，以点（dot）表示		
				y:欲绘制条码的垂直坐标左上角起点，以点（dot）表示
				type:条码类型
						128	  Code 128,条形码subset采用自动选择A,B,C
				 EAN128 	EAN 128
             39 	Auto switch full ASCII and Standard code 39 for plus models.
             93 	Code 93
          EAN13 	EAN13
           EAN8 	EAN 8
           CODA 	Codabar
           UPCA	  UPCA
         UPCE+5 	UPC-E with 5 digits add-on
				height:条形码高度，以点（dot）表示
 humanreadable:
							0，人眼不可识
              1，人眼可识
      rotation:条形码旋转角度，顺时针方向
      				0            不旋转
             90            顺时针防线旋转90度
            180           顺时针防线旋转180度
            270           顺时针防线旋转270度
        narrow:窄条宽度,以点（dot）表示,1<=narrow<=3
          wide:宽条宽度,以点（dot）表示,1<=wide<=7
       content:条码内容
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_PrintBarCode(int x, int y, char *type, int height, int humanreadable, int rotation, int narrow, int wide, char *content)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (height < 0) 
	{
		return -1;
	}
	
	if (humanreadable != 0 && humanreadable != 1) 
	{
		return -1;
	}
	
	if (rotation != 0 && rotation != 90 && rotation != 180 && rotation != 270) 
	{
		return -1;
	}
	
	if (narrow < 1 || narrow > 3) 
	{
		return -1;
	}
	
	if (wide < 1 || wide > 7) 
	{
		return -1;
	}
	
	sprintf(Buf,"BARCODE %d,%d,\"%s\",%d,%d,%d,%d,%d,\"%s\"\r\n",x,y,type,height,humanreadable,rotation,narrow,wide,content);
	
	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印二维码
	* 入口参数：
				x:欲绘制条码的水平坐标左上角起点，以点（dot）表示		
				y:欲绘制条码的垂直坐标左上角起点，以点（dot）表示
				type:条码类型
          QRCODE,DMATRIX,PDF417
        level:ECC LEVEL 选择QRCODE纠错等级(L:7% M:15% Q:25% H:30%)     当选择DATAMATRIX或者PDF417时，表示条码高度
        width:选择QRCode时表示二维码方块宽度1~6，选择DATAMATRIX或这PDF417时表示条码宽度
        rotate:二维码的旋转角度
              0            不旋转
             90            顺时针防线旋转90度
            180            顺时针防线旋转180度
            270            顺时针防线旋转270度
           当选择DATAMATRIX时没有作用
        content:二维码的内容
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_PrintBarCode2D(int x, int y, char *type, char *level, int width, int rotate, char *content)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (x < 0 || y < 0) 
	{
		return -1;
	}
	
	if (width < 0) 
	{
		return -1;
	}
	
	if (rotate != 0 && rotate != 90 && rotate != 180 && rotate != 270) 
	{
		return -1;
	}

	sprintf(Buf,"QRCODE %d,%d,%s,%d,A,%d,\"%s\"\r\n",x,y,level,width,rotate,content);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印位图
	* 入口参数：
				x:点阵影像的水平起始位置(dot)		
				y:点阵影像的垂直起始位置(dot)
				mode:影像绘制模式 (0:OVERWRITE ；1:OR ；2:XOR)
				lpFilePath:位图本地路径
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_DrawBitmap(char *x, char *y, char *mode, char *lpFilePath)
{
//未实现
	
}

/*
	* 功能：打印
	* 入口参数：
				mSets:打印的份数	
				mCopys:每一份中每一标签页打印多少份
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_Print(int mSets, int mCopys)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (mSets < 0 || mCopys < 0) 
	{
		return -1;
	}

	sprintf(Buf,"PRINT %d,%d\r\n",mSets,mCopys);
	
	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：查询打印机状态
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；-1（缺纸）；-2（开盖）;-3（其他错误）
*/
int TSPL_GetPrinterStatus()
{
	int idx=0;
	int ret=-1;
	
	gCmdBuf[idx] = 0x1b;
	idx++;
	gCmdBuf[idx] = 0x21;
	idx++;
	gCmdBuf[idx] = 0x3f;
	idx++;

	gCmdBufLen=idx;
	
	ret=Sprt_net_write(gCmdBuf,gCmdBufLen);
	if(ret!=gCmdBufLen)
	{
		return -3;
	}	
	
	// 读取数据；
	gRcvBufLen=1;
	memset(gRcvBuf,0,sizeof(gRcvBuf));
	ret=Sprt_net_read(gRcvBuf,gRcvBufLen);		
	if(ret<=0)
	{
		return -3;
	}
	
	if(ret!=1)
	{
		return -3;
	}
	
	unsigned char b=gRcvBuf[0];
	int status = 0;

	if (b == 0x00) {
		status = 0;

	} else if (b == -63) {
		status = -2;

	} else if (b == -124) {
		status = -1;

	} else {
		status = -3;
	}
		
	return status;

}

/*
	* 功能：进纸或退纸
	* 入口参数：
				isFeedBack:选择进纸或退纸(0:进纸，1：退纸)
				mDot:退纸点数，当选择进纸时，此参数无效
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SetPaperbackOrPaperFeed(int isFeedBack, int mDot)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (isFeedBack != 0 && isFeedBack != 1) 
	{
		return -1;
	}
	
	if (mDot < 0) 
	{
		return -1;
	}
	
	if(isFeedBack==1)
	{	
		sprintf(Buf,"BACKFEED %d\r\n",mDot);
	}else{
		sprintf(Buf,"FORMFEED\r\n");
	}

	
	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：指定区域内反相打印
	* 入口参数：
				start_x:区域左上角X坐标（dot）
				start_y:区域内左上角Y坐标（dot）
				width:区域的宽度（dot）
				height:区域的高度（dot）
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_ReverseArea(int start_x, int start_y, int width, int height)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (start_x < 0 || start_y < 0) 
	{
		return -1;
	}
	
	if (width < 0 || height < 0) 
	{
		return -1;
	}

	sprintf(Buf,"REVERSE %d,%d,%d,%d\r\n",start_x,start_y,width,height);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：清除影像缓冲区数据
	* 入口参数：
				start_x:区域左上角X坐标（dot）
				start_y:区域左上角Y坐标（dot）
				width:区域的宽度（dot）
				height:区域的高度（dot）
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_EraseArea(int start_x, int start_y,int width, int height)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if (start_x < 0 || start_y < 0) 
	{
		return -1;
	}
	
	if (width < 0 || height < 0) 
	{
		return -1;
	}

	sprintf(Buf,"ERASE %d,%d,%d,%d\r\n",start_x,start_y,width,height);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置打印机相关功能
	* 入口参数：
				command/value:
	 *            1:DIRECTION 设置打印方向；value 为0方向和字体相同，1相反
	 * 
	 *            2:FEED 控制进纸设置；1≤value≤1000 表示点数
	 * 
	 *            3:REPRINT 启用错误重新打印命令；value为0关闭此功能；1开启此功能
	 * 
	 *            4:SPEED 指定打印速度；value为每秒走纸英寸数
	 * 
	 *            5:DENSITY 指定打印浓度；0=<value<=15,数字越大浓度越大
	 * 
	 *            6:SHIFT 走纸偏移value点；value >0,走纸方向和打印方向相同；<0 相反；
	 * 
	 *            7:OFFSET 每单数据打印完成后额外走纸偏移value点
	 * 
	 *            8:FORMFEED 控制打印机进一张纸；value值随意传入
	 * 
	 *            9:HOME 寻起始位置，使缝隙对准撕纸片；value值随意传入
	 * 
	 *            10:PRINTKEY 设定按键打印命令(禁止，启用，自动设定按键打印功能) value为0关闭此功能；1开启此功能
	 * 
	 *            11:KEY1 启用按键KEY1预设功能命令(此按键功能是暂停还是进纸) value为0关闭此功能；1开启此功能
	 * 
	 *            12:KEY2 启用按键KEY2预设功能命令(此按键功能是暂停还是进纸) value为0关闭此功能；1开启此功能
	 * 
	 *            13:TEAR 启用或关闭走到撕纸位置命令(缝隙对准撕纸位) value为0关闭此功能；1开启此功能
	 * 
	 *            14:PEEL 启用剥离模式命令 value为0关闭此功能；1开启此功能
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SetPrinter(int command, int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(command < 1 || command > 14)
	{
		return -1;
	}	
	
	switch (command)
	{
			case 1:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			sprintf(Buf,"DIRECTION %d\r\n",value);
			break;
			
			case 2:
			// 处理参数异常
			if (value < 0 || value > 1000) 
			{
				return -1;
			}
			sprintf(Buf,"FEED %d\r\n",value);
			break;
			
			case 3:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			
			if (value == 0) 
			{
				sprintf(Buf,"SET REPRINT OFF\r\n");
			}else{
				sprintf(Buf,"SET REPRINT ON\r\n");
			}
			break;
			
			case 4:
			// 处理参数异常
			if (value < 0) 
			{
				return -1;
			}
			sprintf(Buf,"SPEED %d\r\n",value);
			break;
			
			case 5:
			// 处理参数异常
			if (value < 0 || value > 15) 
			{
				return -1;
			}
			sprintf(Buf,"DENSITY %d\r\n",value);
			break;
			
			case 6:
			// 处理参数异常
			if (value < (-203) || value > 203) 
			{
				return -1;
			}
			sprintf(Buf,"SHIFT %d\r\n",value);
			break;
			
			case 7:
			// 处理参数异常
			if (value < (-203) || value > 203) 
			{
				return -1;
			}
			sprintf(Buf,"OFFSET %d\r\n",value);
			break;
			
			case 8:
			sprintf(Buf,"FORMFEED\r\n");
			break;
			
			case 9:
			sprintf(Buf,"HOME\r\n");
			break;
			
			case 10:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			
			if (value == 0) 
			{
				sprintf(Buf,"SET PRINTKEY OFF\r\n");
			}else{
				sprintf(Buf,"SET PRINTKEY ON\r\n");
			}
			break;
			
			case 11:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			
			if (value == 0) 
			{
				sprintf(Buf,"SET KEY1 OFF\r\n");
			}else{
				sprintf(Buf,"SET KEY1 ON\r\n");
			}
			break;
			
			case 12:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			
			if (value == 0) 
			{
				sprintf(Buf,"SET KEY2 OFF\r\n");
			}else{
				sprintf(Buf,"SET KEY2 ON\r\n");
			}
			break;
			
			case 13:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			
			if (value == 0) 
			{
				sprintf(Buf,"SET TEAR OFF\r\n");
			}else{
				sprintf(Buf,"SET TEAR ON\r\n");
			}
			break;
			
			case 14:
			// 处理参数异常
			if (value != 0 && value != 1) 
			{
				return -1;
			}
			
			if (value == 0) 
			{
				sprintf(Buf,"SET PEEL OFF\r\n");
			}else{
				sprintf(Buf,"SET PEEL ON\r\n");
			}
			break;
	}

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：开钱箱
	* 入口参数：
				t1:0≤t1≤255
				t2:0≤t2≤255
	*     输出由 t1 和 t2 设定的钱箱开启脉冲到由 m 指定的引脚
	* 
	*     注释： 1) 钱箱开启脉冲高电平时间为 [t1 x 2 ms],低电平时间为 [t2 x 2ms]. 2) 如果 t2
	*     <t1，低电平时间为[t1 x 2 ms]
	
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_OpenCashBox(int t1, int t2)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	sprintf(Buf,"CASHDRAWER 0,%d,%d\r\n",t1,t2);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：查询打印机型号
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_GetPrinterName()
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	sprintf(Buf,"~!T\r\n");

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：设置黑标高度
	* 入口参数：
				blackHeight:黑标高度（dot）
				      value:打印完成后额外走纸距离（dot）
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SetBline(int blackHeight, int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(blackHeight < 0 || blackHeight > 203 || value < 0)
	{
		return -1;
	}	
	
	sprintf(Buf,"BLINE %dmm,%dmm\r\n",blackHeight,value);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置黑标高度
	* 入口参数：
				value:标签纸间垂直间距（单位：mm），mm（0≦m≤1(inch）， 0≦m≤25.4(mm）
			 offset:间隙偏移（单位：mm），offset ≤ label length (inch or mm)
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SetGAP(int value, int offset)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(value < 0 || offset < 0)
	{
		return -1;
	}	
	
	sprintf(Buf,"GAP %dmm,%dmm\r\n",value,offset);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：选择字符代码页
	* 入口参数：
				value:
   *            437: United States
	 * 
	 *            850: Multilingual
	 * 
	 *            852: Slavic
	 * 
	 *            860: Portuguese
	 * 
	 *            863: Canadian/French
	 * 
	 *            865: Nordic
	 * 
	 *            857: Turkish
	 * 
	 *            1250: Central Europe
	 * 
	 *            1252: Latin I
	 * 
	 *            1253: Greek
	 * 
	 *            1254: Turkish
	 * 
	 *            传入其他值：默认为437
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SelectGodePage(int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(value < 0)
	{
		return -1;
	}	
	
	switch (value) {
		case 437:

			break;
		case 850:

			break;
		case 852:

			break;
		case 860:

			break;
		case 863:

			break;
		case 865:

			break;
		case 1250:

			break;
		case 1252:

			break;
		case 1253:

			break;
		case 1254:

			break;

		default:
			value = 437;
			break;
	}
	
	sprintf(Buf,"CODEPAGE %d\r\n",value);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：选择国际字符集
	* 入口参数：
				value:
	 *            1: USA
	 * 
	 *            2: Canadian-French
	 * 
	 *            3: Spanish (Latin America)
	 * 
	 *            33:French (France)
	 * 
	 *            34: Spanish (Spain)
	 * 
	 *            39: Italian
	 * 
	 *            42: Slovak
	 * 
	 *            44:United Kingdom
	 * 
	 *            45: Danish
	 * 
	 *            46: Swedish
	 * 
	 *            47: Norwegian
	 * 
	 *            49: German
	 * 
	 *            61: English (International)
	 * 
	 *            传入其他值：默认为1
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SelectCountry(int value)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	char *str;
	
	if(value < 0)
	{
		return -1;
	}

	switch (value) {
		case 1:
			str = "001";
			break;
		case 2:
			str = "002";
			break;
		case 3:
			str = "003";
			break;
		case 33:
			str = "033";
			break;
		case 34:
			str = "034";
			break;
		case 39:
			str = "039";
			break;
		case 42:
			str = "042";
			break;
		case 44:
			str = "044";
			break;
		case 45:
			str = "045";
			break;
		case 46:
			str = "046";
			break;
		case 47:
			str = "047";
			break;
		case 49:
			str = "049";
			break;
		case 61:
			str = "061";
			break;
		default:
			str = "001";
			break;
	}
	
	sprintf(Buf,"COUNTRY %s\r\n",str);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
}

/*
	* 功能：控制蜂鸣器响一声
	* 入口参数：
				level:蜂鸣器响的级别 1≤level≤9
		 interval:蜂鸣器响的时间 间隔（单位ms）1≤interval≤4095
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_Beep(int level, int interval)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(level < 1 || level > 9 || interval < 1 || interval > 4095)
	{
		return -1;
	}
	
	sprintf(Buf,"SOUND %d,%d\r\nBEEP\r\n",level,interval);

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：打印自检页
	* 入口参数：无
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_PrintSelfTestTSP()
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	sprintf(Buf,"SELFTEST\r\n");

	int len=strlen(Buf);
	
	ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;	
	
}

/*
	* 功能：设置标签的参考坐标原点，调整标签内容在标签纸上的位置
	* 入口参数：
				left:标签内容距离标签纸的左边距（mm）
		     top:标签内容距离标签纸的上边距（mm）
	* 出口参数：无
	* 返回值：0（正常）；<0（错误）；
*/
int TSPL_SetLabelReference(int left, int top)
{
	int ret = -1;
	unsigned char Buf[256]={0};
	
	if(left < 0 || top < 0)
	{
		return -1;
	}
	
	sprintf(Buf,"REFERENCE %d,%d\r\n",left,top);

	int len=strlen(Buf);
	
	//-----------ztongli.2016.12.22-------------
	emptyAttribute(&al);
	al.cmdBuf			=	Buf;
	al.bufLen			=	len;
	ret					=	writeData(&al);
	//-----------ztongli.2016.12.22-------------
	
	//ret=Sprt_net_write(Buf,len);
	if(ret!=len)
	{
		return -1;
	}	
	
	return 0;		
	
}

/////////////////////////////////////TSPL//////////////////////////////////////
// 日志记录函数; 
void DoLog(unsigned char *pLogMsg,int logMsgLen)
{

	if((pLogMsg==NULL)||(logMsgLen==0))
	{
		return ;
	}		
	
	unsigned char logPathBuf[256]={0};
//	sprintf(logPathBuf,"%s/log/%s",gOutputDir,LOGFILE);
	sprintf(logPathBuf,"/tmp/%s",LOGFILE);

	FILE *fp=fopen(logPathBuf,"ab");
	if(fp==NULL)
	{
		printf("qzf at DoLog() ab fp==NULL!\r\n");
		return;
	}		
 	fseek(fp, 0L, SEEK_END);  
  int fileSize = ftell(fp);  
  if(fileSize>MAXLOGFILESIZE)
  {
		printf("qzf at DoLog() fileSize>MAXLOGFILESIZE ! fileSize=%d\r\n",fileSize);
		fclose(fp);
		fp=fopen(logPathBuf,"w+");			// 清空日志文件;
		if(fp==NULL)
		{
			printf("qzf at DoLog() w+ fp==NULL!\r\n");
			return;
  	}		
  	fclose(fp);
		return;
	
	}		
	fclose(fp);
    
	time_t timer;				//time_t就是long int 类型
	struct tm *tblock;
	timer = time(NULL);		//这一句也可以改成time(&timer);
	tblock = localtime(&timer);	

	unsigned char tempBuf[512]={0};

	sprintf(tempBuf,"%04d-%02d-%02d %02d:%02d:%02d ",(tblock->tm_year+1900),tblock->tm_mon,tblock->tm_mday,tblock->tm_hour,tblock->tm_min,tblock->tm_sec);
	
	unsigned char lineBuf[1024];
	int len=strlen(tempBuf);
	strcpy(lineBuf,tempBuf);
	lineBuf[len++]='[';
	memcpy((unsigned char *)&lineBuf[len],pLogMsg,logMsgLen);
	len+=logMsgLen;
	lineBuf[len++]=']';
	lineBuf[len++]=0x0d;
	lineBuf[len++]=0x0a;
	
	fp=fopen(logPathBuf,"a+");
	if(fp==NULL)
	{
		printf("qzf at DoLog() fp==NULL!\r\n");
		return;
  }		
	fwrite(lineBuf,1,len,fp);
	fclose(fp);
	
	return;	
	
}

void InitGlobalVar()
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c InitGlobalVar() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	gCmdBufLen=0;
	gRcvBufLen=0;
	gCmdBuf[0]=0;
	gCmdBufLen=0;
	gRcvBuf[0]=0;
	gRcvBufLen=0;
	
	pthread_mutex_init(&gPUsb_mutex,NULL);
	pthread_mutex_init(&gPLog_mutex,NULL);

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c InitGlobalVar() finished.");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	return;
}

//2016.12.21.
//端点描述符
static void print_endpoint(struct libusb_endpoint_descriptor *endpoint)
{
  printf("      bEndpointAddress: %xh\n", endpoint->bEndpointAddress);
  printf("      bmAttributes:     %xh\n", endpoint->bmAttributes);
  printf("      wMaxPacketSize:   %d\n", endpoint->wMaxPacketSize);
  printf("      bInterval:        %d\n", endpoint->bInterval);
  printf("      bRefresh:         %d\n", endpoint->bRefresh);
  printf("      bSynchAddress:    %d\n", endpoint->bSynchAddress);
}


// 发送函数; 成功：返回值等于pBufLen，其他失败;
int Sprt_usb_write(unsigned char *pBuf,int pBufLen,int sleepTime)
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));
	
	if(pBufLen<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() pBufLen<0,pBufLen=%d",pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}		
	if(pBufLen==0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() pBufLen=0");
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;
	}		
	pthread_mutex_lock(&gPUsb_mutex);

	unsigned char tempBuf[WRITEBYTEMAX]={0};
	int divInt=pBufLen/WRITEBYTEMAX;
	int modInt=pBufLen%WRITEBYTEMAX;
	int i=0;
	int retNum=0;
	int ret=-1;

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() pBufLen=%d,divInt=%d,modInt=%d",pBufLen,divInt,modInt);
	DoLog(gLogBuf,strlen(gLogBuf));
	printf("divInt:%d,pBufLen:%d,WRITEBYTEMAX:%d,modInt:%d\n",divInt,pBufLen,WRITEBYTEMAX,modInt);
	for( i=0; i<divInt;i++)
	{
		memcpy(tempBuf,(unsigned char *)&pBuf[i*WRITEBYTEMAX],WRITEBYTEMAX);
		ret=libusb_bulk_transfer(gDev_handle,usbctrl.bOutEndpointAddress, tempBuf,WRITEBYTEMAX, &retNum, sleepTime);
		if((ret !=0)||(retNum!=WRITEBYTEMAX)) 
    {
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() libusb_bulk_transfer() fail! i=%d,ret=%d,retNum=%d",i,ret,retNum);
			DoLog(gLogBuf,strlen(gLogBuf));

    	pthread_mutex_unlock(&gPUsb_mutex);
    	
    	return -2;
  	}
	}
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() libusb_bulk_transfer() ok! i=%d,divInt=%d,modInt=%d",i,divInt,modInt);
	DoLog(gLogBuf,strlen(gLogBuf));
	
	if(modInt!=0)
	{	
		memcpy(tempBuf,(unsigned char *)&pBuf[i*WRITEBYTEMAX],modInt);
		int templen	=	strlen(tempBuf);
		/*struct libusb_endpoint_descriptor desc;
		print_endpoint(&desc);*/
		
		ret=libusb_bulk_transfer(gDev_handle,usbctrl.bOutEndpointAddress, tempBuf,modInt, &retNum, sleepTime);
		//printf("Sprt_usb_write,ret:%d,retNum:%d,sleepTime:%d,templen:%d,",ret,retNum,sleepTime,templen );
		//printf("libusb_error_name:%s\n",libusb_error_name(ret));
		if((ret !=0)||(retNum!=modInt))
    {
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() libusb_bulk_transfer() fail2! ret=%d,retNum=%d,modInt=%d",ret,retNum,modInt);
			DoLog(gLogBuf,strlen(gLogBuf));

    	pthread_mutex_unlock(&gPUsb_mutex);
    	
    	return -3;
  	}
  }		
  
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_write() finished.");
	DoLog(gLogBuf,strlen(gLogBuf));

 	pthread_mutex_unlock(&gPUsb_mutex);

  return pBufLen;
	
}
// 接收函数; pBufLen为期望接收到的字节个数; 成功：返回值为实际读取的字节数,其他失败;
int Sprt_usb_read(unsigned char *pBuf,int pBufLen,int sleepTime)
{

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_read() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(pBufLen<0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_read() pBufLen<0,pBufLen=%d",pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}		
	if(pBufLen==0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_read() finished. pBufLen=%d",pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;
	}		
	pthread_mutex_lock(&gPUsb_mutex);

	int retNum=0;
	int ret=-1;
	
	//---------2016.12.21.ztongli------------
	/*
	*			发送查询状态的指令到打印机时，执行此第三方库方法libusb_bulk_transfer是获得打印机返回的状态也就是一个字符
				此方法第一次执行时从缓冲区内获取不到字符，第二次执行时却接收到两个字符，
				推断第一次执行时设置的超时等待比较短，但是增大甚至使用无限超时0时也还是同样的结果
				遂使用以下方法暂时将就...待更改
	*
	*/
	unsigned char tmpBuf[1024] = {0};
	
	do
	{
		ret=libusb_bulk_transfer(gDev_handle,usbctrl.bInEndpointAddress, tmpBuf,sizeof(tmpBuf), &retNum, 0);
		
	}while(tmpBuf[0] == 0);
	
	retNum		=	pBufLen;	
	memcpy(pBuf,tmpBuf,retNum);
	
	//printf("Sprt_usb_read,ret:%d,retNum:%d,pBufLen:%d,",ret,retNum,pBufLen);
	//printf("libusb_error_name:%s\n",libusb_error_name(ret));
	
	/*int i;
	for(i=0;i < sizeof(tmpBuf);i++)
	{
		printf("\r\r\r\r\r\r%d\n",(int)tmpBuf[i]);
	}*/
	//---------2016.12.21.ztongli------------
	
	
//	if((ret !=0)||(retNum!=pBufLen)) 
	if((ret !=0)||(retNum<=0)) 
  {
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_read() read fail! ret=%d,retNum=%d,pBufLen=%d",ret,retNum,pBufLen);
		DoLog(gLogBuf,strlen(gLogBuf));

  	pthread_mutex_unlock(&gPUsb_mutex);
  	
  	return -2;
	}

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_read() finished. retNum=%d,pBuf[0]=%02x",retNum,pBuf[0]);
	DoLog(gLogBuf,strlen(gLogBuf));

 	pthread_mutex_unlock(&gPUsb_mutex);


  return retNum;	
}	

static int FindEndpoint(u_int8_t * bInAddress,u_int8_t *bOutAddress,const struct libusb_interface_descriptor *interface)
{
	sprintf(gLogBuf,"FindEndpoint Begin ... interface->bNumEndpoints = %d",interface->bNumEndpoints);
	DoLog(gLogBuf,strlen(gLogBuf));

	int i;
	int ret=0;
	for(i = 0; i < interface->bNumEndpoints; i++)
	{
		sprintf(gLogBuf,"FindEndpoint A bmAttributes = %02x",interface->endpoint[i].bmAttributes);
		DoLog(gLogBuf,strlen(gLogBuf));

		if((interface->endpoint[i].bmAttributes & 0x03) == 0x02)
		{
			if(interface->endpoint[i].bEndpointAddress & 0x80)
			{
				sprintf(gLogBuf,"FindEndpoint B bEndpointAddress = %02x",interface->endpoint[i].bEndpointAddress);
				ret|=1;
				*bInAddress=interface->endpoint[i].bEndpointAddress;
			}
			else
			{
				sprintf(gLogBuf,"FindEndpoint C bEndpointAddress = %02x",interface->endpoint[i].bEndpointAddress);
				ret|=2;
				*bOutAddress=interface->endpoint[i].bEndpointAddress;
			}
			DoLog(gLogBuf,strlen(gLogBuf));
		}								
	}
	if(ret==3){
		sprintf(gLogBuf,"FindEndpoint End Success ret = %d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		return 1;
	}else{
		sprintf(gLogBuf,"FindEndpoint End Fail ret = %d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;
	}
}

int FindInterface(struct libusb_device_descriptor * desc,libusb_device *dev )
{
	sprintf(gLogBuf,"FindInterface() Ready To Find Interface Info !");
	DoLog(gLogBuf,strlen(gLogBuf));

	struct libusb_config_descriptor *conf_desc;
	int i,j,k;
	int isFind = 0; 
	
	u_int8_t  bInterfaceNumber;
	u_int8_t  bInEndpointAddress;
	u_int8_t  bOutEndpointAddress; 
    
	sprintf(gLogBuf, "FindInterface A desc->bNumConfigurations = %d",desc->bNumConfigurations);
	DoLog(gLogBuf,strlen(gLogBuf));

    for (i=0; i< desc->bNumConfigurations; i++) 
    {
    	libusb_get_config_descriptor(dev, i, &conf_desc); 
		sprintf(gLogBuf, "FindInterface B conf_desc->bNumInterfaces = %d",conf_desc->bNumInterfaces);
		DoLog(gLogBuf,strlen(gLogBuf));

		for (j=0; j< conf_desc->bNumInterfaces; j++)
		{				
			sprintf(gLogBuf, "FindInterface C conf_desc->interface[j].num_altsetting = %d",conf_desc->interface[j].num_altsetting);
			DoLog(gLogBuf,strlen(gLogBuf));
			for (k=0; k< conf_desc->interface[j].num_altsetting; k++) 
			{
				sprintf(gLogBuf, "FindInterface D bInterfaceClass = %02x bInterfaceSubClass = %02x",
							conf_desc->interface[j].altsetting[k].bInterfaceClass,conf_desc->interface[j].altsetting[k].bInterfaceSubClass);
				DoLog(gLogBuf,strlen(gLogBuf));

				//if(conf_desc->interface[j].altsetting[k].bInterfaceClass == 0xff && conf_desc->interface[j].altsetting[k].bInterfaceSubClass == 0xff)
				//{
					if(FindEndpoint(&bInEndpointAddress,&bOutEndpointAddress,&(conf_desc->interface[j].altsetting[k])))
					{
						bInterfaceNumber = conf_desc->interface[j].altsetting[k].bInterfaceNumber;

						sprintf(gLogBuf, "FindEndpoint bInEndpointAddress = %02x bOutEndpointAddress = %02x bInterfaceNumber = %02x",
														bInEndpointAddress,bOutEndpointAddress,bInterfaceNumber);
						DoLog(gLogBuf,strlen(gLogBuf));

						libusb_free_config_descriptor(conf_desc);
						isFind = 1;
						goto DINFINTERFACE;
					}
				//}				
			}
		}
		libusb_free_config_descriptor(conf_desc);
    }
DINFINTERFACE :
	if(isFind){
		usbctrl.bInEndpointAddress = bInEndpointAddress;
		usbctrl.bOutEndpointAddress = bOutEndpointAddress;
		usbctrl.bInterfaceNumber = bInterfaceNumber;
		usbctrl.idVendor = desc->idVendor ;
		usbctrl.idProduct = desc->idProduct;
		return 1;
	}else{
		return 0;
	} 
}

//查找USB端点
int GetEndPoint(libusb_device **devs)
{
	sprintf(gLogBuf,"GetEndPoint() Ready To Get Device Info!");
	DoLog(gLogBuf,strlen(gLogBuf));

    libusb_device *dev;
    int i = 0;
	int nRet = 0;

    while ((dev = devs[i++]) != NULL) {
        struct libusb_device_descriptor desc;
        int r = libusb_get_device_descriptor(dev, &desc);
        if (r < 0) {
            sprintf(gLogBuf, "GetEndPoint() failed to get device descriptor");
			DoLog(gLogBuf,strlen(gLogBuf));
            return nRet;
        }
        
		if (desc.idVendor == VID && desc.idProduct == PID){
			sprintf(gLogBuf,"GetEndPoint : %04x:%04x (bus %d, device %d)\n",desc.idVendor, desc.idProduct,
            											libusb_get_bus_number(dev), libusb_get_device_address(dev));
			DoLog(gLogBuf,strlen(gLogBuf));

			if (FindInterface(&desc,dev)){
				sprintf(gLogBuf, "FindInterface() EndPointIn = %02x EndPointOut = %02x",
										usbctrl.bInEndpointAddress,usbctrl.bOutEndpointAddress);
				DoLog(gLogBuf,strlen(gLogBuf));
				nRet = 1;
			}else{
				sprintf(gLogBuf,"FindInterface Failed!");
				DoLog(gLogBuf,strlen(gLogBuf));
			}
			break;
		}
    }
	sprintf(gLogBuf,"GetEndPoint() Finish Get Device Info!");
	return nRet;
}


// 开口函数; 返回值: 0 成功，其他失败；
int Sprt_usb_open()
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	pthread_mutex_lock(&gPUsb_mutex);

	libusb_device **devs;											//pointer to pointer of device, used to retrieve a list of devices
//	libusb_device_handle *dev_handle;					//a device handle
	int ret=-1;																//for return values
	ssize_t cnt;															//holding number of devices in list
	ret = libusb_init(&gCtx);									//initialize the library for the session we just declared
 
	if(ret <0)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() libusb_init() fail! ret=%d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
 		
 		pthread_mutex_unlock(&gPUsb_mutex);
		return -1;
	}
	
	libusb_set_debug(gCtx, 3);									//set verbosity level to 3, as suggested in the documentation
 
	cnt = libusb_get_device_list(gCtx,&devs);	//get the list of devices
	if(cnt <0){
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() libusb_get_device_list() fail! cnt=%d",cnt);
		DoLog(gLogBuf,strlen(gLogBuf));
 
 		pthread_mutex_unlock(&gPUsb_mutex);
		return -2;
	}
 
	//查找USB设备端点，包括EndPointIn 和 EndPointOut
	if (!GetEndPoint(devs)){
		sprintf(gLogBuf,"garland HWISPRTPrinter.c Sprt_usb_open() GetEndPoint() Failed!");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -3;
	}

	gDev_handle = libusb_open_device_with_vid_pid(gCtx,VID,PID);		//these are vendorID and productID I found for my usb device
	if(gDev_handle ==NULL)
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() libusb_open_device_with_vid_pid() fail! gDev_handle==NULL");
		DoLog(gLogBuf,strlen(gLogBuf));

 		pthread_mutex_unlock(&gPUsb_mutex);
		return -4;
	}	
  
  libusb_free_device_list(devs, 1);				//free the list, unref the devices in it
 
 	ret=libusb_kernel_driver_active(gDev_handle,0);
  if(ret==1)
  {			//find out if kernel driver is attached
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() libusb_kernel_driver_active() ret=%d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));

		ret=libusb_detach_kernel_driver(gDev_handle,0);
		if(ret==0)			//detach it
		{
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() libusb_detach_kernel_driver()ret=%d",ret);
			DoLog(gLogBuf,strlen(gLogBuf));

		}		
  }
  ret = libusb_claim_interface(gDev_handle,0);							//claim interface 0 (the first) of device (mine had jsut 1)
	if(ret <0){
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() libusb_claim_interface() fail! ret<0,ret=%d",ret);
		DoLog(gLogBuf,strlen(gLogBuf));

 		pthread_mutex_unlock(&gPUsb_mutex);
		return -5;
	}

	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_open() finished.");
	DoLog(gLogBuf,strlen(gLogBuf));

	pthread_mutex_unlock(&gPUsb_mutex);
	return 0;
	
}

// 关口函数; 返回值: 0 成功，其他失败；
int Sprt_usb_close()
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_close() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(gDev_handle!=NULL)
	{
		int ret = libusb_release_interface(gDev_handle,0);	//release the claimed interface
		if(ret!=0){
			sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_close() ret!=0,ret=%d,gDev_handle=%x",ret,gDev_handle);
			DoLog(gLogBuf,strlen(gLogBuf));
			return -1;
		}
		libusb_close(gDev_handle);//close the device we opened
		libusb_exit(gCtx);//needs to be called to end the
			
	}
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_usb_close() finished.");
	DoLog(gLogBuf,strlen(gLogBuf));

	return 0;
}
////////////////////////////////////////////////////////////////网口函数实现,WX_20160811,Begin////////////////////////////////////////////////
// 网口开口函数; 返回值: 0 成功，其他失败；
int Sprt_net_open(char *ipAddress)
{

    //创建用于internet的流协议(TCP)socket,用socketFd代表客户机socket
    socketFd = socket(AF_INET, SOCK_STREAM, 0);
    sprintf(gLogBuf,"socketFd=%d",socketFd);
    DoLog(gLogBuf,strlen(gLogBuf));
    if (socketFd < 0)
    {
        printf("Create Socket Failed!\n");
        return -1;
    }
 
    //设置一个socket地址结构server_addr,代表服务器的internet地址, 端口
    struct sockaddr_in server_addr;
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;

    //char *pIp="192.168.1.114";
    char *pIp=ipAddress;
    if (inet_aton(pIp, &server_addr.sin_addr) == 0) //服务器的IP地址来自程序的参数
    {
        printf("Server IP Address Error! \n");
        return -1;
    }
 
    server_addr.sin_port = htons(SERVER_PORT);
    socklen_t server_addr_length = sizeof(server_addr);
    // 向服务器发起连接,连接成功后socketFd代表了客户机和服务器的一个socket连接

    int ret=connect(socketFd, (struct sockaddr*) &server_addr,
            server_addr_length) ;
    printf("ret=%d\n",ret);
    if (ret < 0)
    {
        printf("Can Not Connect ! \n");
        return -1;
    }
    sprintf(gLogBuf,"socketFd=%d",socketFd);
    DoLog(gLogBuf,strlen(gLogBuf));
    return 0;
}
// 网口关口函数; 返回值: 0 成功，其他失败；
int Sprt_net_close()
{
	sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_net_close() begin...");
	DoLog(gLogBuf,strlen(gLogBuf));

	if(socketFd!=-1)
	{
		close(socketFd);
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_net_close() finished.");
		DoLog(gLogBuf,strlen(gLogBuf));
		return 0;	
	}
	else
	{
		sprintf(gLogBuf,"qzf at HWISPRTPrinter.c Sprt_net_close() socketFd==-1");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}		


}
// 网口接收函数; pBufLen为期望接收到的字节个数; 成功：返回值为实际读取的字节数,其他失败;
int Sprt_net_read(unsigned char *pBuf,int pBufLen)
{
	
	int bytes_left;
	int bytes_read;
	//char *pBuf;
   
	bytes_left=pBufLen;
	while(bytes_left>0)
	{
		sprintf(gLogBuf,"socketFd=%d",socketFd);
		DoLog(gLogBuf,strlen(gLogBuf));

   		bytes_read=read(socketFd,pBuf,bytes_left);

		sprintf(gLogBuf,"bytes_read=%d",bytes_read);
		DoLog(gLogBuf,strlen(gLogBuf));
  		if(bytes_read<0)
   		{
			if(errno==EINTR)
      	 		bytes_read=0;
    			else
       	 		return(-1);
  	 	}
  	 	else if(bytes_read==0)
      	 	break;
    		bytes_left-=bytes_read;
   	 	pBuf+=bytes_read;
	}
	sprintf(gLogBuf,"pBuf[0]=%02x",pBuf[0]);
	DoLog(gLogBuf,strlen(gLogBuf));
	return(pBufLen-bytes_left);
	
}
// 网口发送函数; 成功：返回0，其他失败;
int Sprt_net_write(unsigned char *pBuf,int pBufLen)

{
	int bytes_left;
	int written_bytes;
	char *ptr;
 
	ptr=pBuf;
	bytes_left=pBufLen;
	//written_bytes=send(socketFd,ptr,bytes_left,0);
	//sprintf(gLogBuf,"written_bytes=%d,socketFd=%d,bytes_left=%d",written_bytes,socketFd,bytes_left);
	//DoLog(gLogBuf,strlen(gLogBuf));
	while(bytes_left>0)
	{
        	/* 开始写*/
        	written_bytes=write(socketFd,ptr,bytes_left);
		//written_bytes=send(socketFd,ptr,bytes_left,0);
		sprintf(gLogBuf,"written_bytes=%d",written_bytes);
		DoLog(gLogBuf,strlen(gLogBuf));
        	if(written_bytes<=0) /* 出错了*/
        	{       
                	if(errno==EINTR) /* 中断错误 我们继续写*/
                        	written_bytes=0;
               		else             /* 其他错误 没有办法,只好撤退了*/
                        	return(-1);
        	}
        	bytes_left-=written_bytes;
        	ptr+=written_bytes;     /* 从剩下的地方继续写  */
	}

	return(pBufLen);

}
////////////////////////////////////////////////////////////////网口函数实现,WX_20160811,Een



//------------------2016.12.19.ztongli----------------
//打开端口
int OpenPort(int port, char* parameter)
{
	
	int ret			=	-1;
	int isParam		=	1;
	if(parameter == NULL)
	{
		isParam		=	0;
	}
	
	
	switch(port)
	{
	case USB_PORT:
		ret			=	Sprt_usb_open();
		if( ret<0)
		{	
			//printf("libusb_error_name:%s\n",libusb_error_name(ret));
			sprintf(gLogBuf,"HWISPRTPrinter.c OpenPort() Sprt_usb_open() fail ret=%d",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_usb_open() ok ret=%d\n",ret);
		break;
	case SERIAL_PORT:
		if(!isParam)
		{
			//printf("When the port is a serial port, the parameter cannot be empty\n");
			sprintf(gLogBuf,"When the port is a serial port, the parameter cannot be empty");
			DoLog(gLogBuf,strlen(gLogBuf));
			return -1;
		}
		//printf("parameter:%s\n",parameter);
		ret			=	Sprt_serial_open(parameter);
		if( ret<0)
		{	
			//printf("Sprt_serial_open() fail ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_serial_open() fail ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_serial_open() ok ret=%d\n",ret);
		sprintf(gLogBuf,"Sprt_serial_open() ok ret=%d\n",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		break;
	case NET_PORT:
		if(!isParam)
		{
			//printf("When the port is a net port, the parameter cannot be empty\n");
			sprintf(gLogBuf,"When the port is a net port, the parameter cannot be empty");
			DoLog(gLogBuf,strlen(gLogBuf));
			return -1;
		}
		//printf("parameter:%s\n",parameter);
		ret			=	Sprt_net_open(parameter);
		if( ret<0)
		{	
			//printf("Sprt_net_open() fail ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_net_open() fail ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_net_open() ok ret=%d\n",ret);
		sprintf(gLogBuf,"Sprt_net_open() ok ret=%d\n",ret);
		DoLog(gLogBuf,strlen(gLogBuf));
		break;
	default:
		printf("Please enter port macros\n");
		return -5;
	}
	setAttribute(port);
	
	return ret;
}


//关闭端口
int ClosePort()
{
	int ret			=	-1;
	switch(al.flag)
	{
	case USB_PORT:
		ret=Sprt_usb_close();
		if( ret<0)
		{	
			//printf("Sprt_usb_close() fail ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_usb_close() fail ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		else
		{
			//printf("Sprt_usb_close() ok ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_usb_close() ok ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
		}	
		break;
	case SERIAL_PORT:
		ret=Sprt_serial_close();
		if( ret<0)
		{	
			//printf("Sprt_serial_close() fail ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_serial_close() fail ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		else
		{
			//printf("Sprt_serial_close() ok ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_serial_close() ok ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
		}			
		break;
	case NET_PORT:
		ret=Sprt_net_close();
		if( ret<0)
		{	
			//printf("Sprt_net_close() fail ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_net_close() fail ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		else
		{
			//printf("Sprt_net_close() ok ret=%d\n",ret);
			sprintf(gLogBuf,"Sprt_net_close() ok ret=%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
		}			
		break;
	default:
		printf("Please enter port macros\n");
		return -5;
	}

	return ret;
}

//发送数据
int writeData(AL* attr)
{
	if(attr->cmdBuf == NULL)
	{
		//printf("attr is not null\n");
		sprintf(gLogBuf,"writeData attr->cmdBuf null");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}
	if(attr->bufLen == 0)
	{
		attr->bufLen		=	strlen(attr->cmdBuf);
	}

	int ret			=	-1;
	switch(attr->flag)
	{
	case USB_PORT:
		ret			=	Sprt_usb_write(attr->cmdBuf,attr->bufLen,attr->sleepTime = 10);
		if(ret < 0)
		{
			//printf("Sprt_usb_write err:%d\n",ret);
			sprintf(gLogBuf,"Sprt_usb_write err:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_usb_write OK\n");
		break;
	case SERIAL_PORT:
		ret			=	Sprt_serial_write(attr->cmdBuf,attr->bufLen);
		if(ret < 0)
		{
			//printf("Sprt_serial_write err:%d\n",ret);
			sprintf(gLogBuf,"Sprt_serial_write err:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_serial_write OK\n");
		break;
	case NET_PORT:
		ret			=	Sprt_net_write(attr->cmdBuf,attr->bufLen);
		if(ret < 0)
		{
			//printf("Sprt_net_write err:%d\n",ret);
			sprintf(gLogBuf,"Sprt_net_write err:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_net_write OK\n");
		break;
	default:
		printf("Please enter port macros\n");
		return -5;
	}

	return ret;
}

//读取数据
int readData(AL* attr)
{
	if(attr->cmdBuf == NULL)
	{
		//printf("attr.cmdBuf is not null\n");
		sprintf(gLogBuf,"readData attr->cmdBuf null");
		DoLog(gLogBuf,strlen(gLogBuf));
		return -1;
	}
	
	int ret			=	-1;
	switch(attr->flag)
	{
	case USB_PORT:
		ret			=	Sprt_usb_read(attr->cmdBuf,attr->bufLen,attr->sleepTime = 10);
		if(ret < 0)
		{
			//printf("Sprt_usb_read err:%d\n",ret);
			sprintf(gLogBuf,"Sprt_usb_read err:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		else if(ret == 0)
		{
			//printf("Sprt_usb_read not data ret:%d\n",ret);
			sprintf(gLogBuf,"Sprt_usb_read not data ret:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_usb_read OK\n");
		break;
	case SERIAL_PORT:
		ret			=	Sprt_serial_read(attr->cmdBuf,attr->bufLen,attr->sleepTime = 5);
		if(ret < 0)
		{
			//printf("Sprt_serial_read err:%d\n",ret);
			sprintf(gLogBuf,"Sprt_serial_read err:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		else if(ret == 0)
		{
			//printf("Sprt_serial_read not data ret:%d,sleepTime:%d\n",ret,attr->sleepTime);
			sprintf(gLogBuf,"Sprt_serial_read not data ret:%d,sleepTime:%d\n",ret,attr->sleepTime);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_serial_read OK\n");
		break;
	case NET_PORT:
		ret			=	Sprt_net_read(attr->cmdBuf,attr->bufLen);
		if(ret < 0)
		{
			//printf("Sprt_net_read err:%d\n",ret);
			sprintf(gLogBuf,"Sprt_net_read err:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		else if(ret == 0)
		{
			//printf("Sprt_net_read not data ret:%d\n",ret);
			sprintf(gLogBuf,"Sprt_net_read not data ret:%d\n",ret);
			DoLog(gLogBuf,strlen(gLogBuf));
			return ret;
		}
		//printf("Sprt_net_read OK\n");
		break;
	default:
		printf("Please enter port macros\n");
		return -5;
	}

	return ret;
}

//设置端口宏
int setAttribute(int port)
{
	emptyAttribute(&al);
	if(port == USB_PORT || port == SERIAL_PORT || port == NET_PORT)
	{
		al.flag		=	port;
		return 0;
	}
	printf("Please enter port macros\n");
	return -1;
}

//清空全局AL结构体的个别成员
void emptyAttribute(AL* attr)
{
	attr->cmdBuf		=	NULL;
	attr->bufLen		=	0;
	attr->sleepTime		=	0;
}


//--------2016.12.13.ztongli
int  QueryErrState()
{
	
	unsigned char cmd[]				= {0x10,0x04,0x03,0};
	int BufLen				= strlen(cmd);
	int res						= -1;
	//-----------ztongli.2016.12.20-------------
	emptyAttribute(&al);
	al.cmdBuf			=	cmd;
	al.bufLen			=	BufLen;
	res					  =	writeData(&al);
	//-----------ztongli.2016.12.20-------------
	//int res 					= Sprt_serial_write(cmd,BufLen);
	
	/*printf("Sprt_serial_write:%d,cmd:%d\n",res,(int)cmd[0]);
	printf("Sprt_serial_write:%d,cmd:%d\n",res,(int)cmd[1]);
	printf("Sprt_serial_write:%d,cmd:%d\n",res,(int)cmd[2]);*/
	
	unsigned char ResState[3]  = {0};
	
	if(res == BufLen)
	{
				//--------------2016.12.20.ztongli--------------
				emptyAttribute(&al);
				al.cmdBuf		=	ResState;
				al.bufLen		=	1;
				res		=	readData(&al);
				//--------------2016.12.20.ztongli--------------
				//res						=	Sprt_serial_read(ResState,1,5);
				
				if(res != 1)
				{
					return -3;
				}   
 				//printf("res:%d,str:%x,strlen:%d\n",res,(int)ResState[0],strlen(ResState));	
 				int bin				=	(int)ResState[0];
 				//int bin	= (int)0x72;
 				if(bin == 18)//00010010
 				{
 						return 0;
 						//return "无不可恢复错误&没有自动恢复错误";
 				}
 				else if(bin == 50)//00110010
 				{
 						return 1;
 						//return "有不可恢复错误";
 				}
 				else if(bin == 82)//01010010
 				{
 						return 2;
 						//return "有自动恢复错误出现";
 				}
 				else if(bin == 114)//01110010
 				{
 						return 3;
 						//return "有自动恢复错误出现&有不可恢复错误";
 				}
	}

	return -1;
}