
#include <stdio.h>
#include "HWISPRTPrinter.h"
//include <libusb.h>

void main()
{
	int ret=-1;

	//char *ipAddress  = "192.168.1.114"; //网口,WX_20160811
	char ip[256];
	bzero(ip, 256);
	printf("Please Input IP: ");
	scanf("%s", ip);

	setAttribute(NET_PORT);
	ret=OpenPort(ip);
	if( ret<0)
	{	
		printf("OpenPort() fail ret=%d\n",ret);
		return;
	}
	printf("OpenPort() ok ret=%d\n",ret);

/*************************************************************************/	
/*
//韵达样条数据：
! 0 200 200 1256 1
PAGE-WIDTH 608
LINE 12 192 576 192 1
LINE 12 448 440 448 1
LINE 12 512 440 512 1
LINE 12 775 576 775 1
LINE 12 1162 576 1162 1
LINE 440 192 440 670 1
LINE 440 775 440 940 1
SETBOLD 0
TEXT 55 0 24 8 始发网点： 网点程序测试
TEXT 55 0 80 40 收件人： 吴先生
TEXT 55 0 80 60 电话：  13800138001
TEXT 55 0 80 80 收件地址： 上海市,上海市,青浦区上海市上海市青浦区
TEXT 55 0 80 100 盈港东路6679号
TEXT 55 0 448 8 体积：
TEXT 55 0 448 28 2015/3/11
TEXT 55 0 448 48 14:6:23
SETBOLD 1
TEXT 24 0 24 40 送达
TEXT 24 0 24 65 地址
TEXT 55 3 16 160 集包地：上海zz
TEXT 24 0 328 8 0.000 KG
TEXT 24 0 328 33 逆向物流
SETBOLD 1
TEXT 55 5 136 368 沪青浦
TEXT 4 1 200 200 1 8 5
TEXT 4 1 200 280 9 6
SETBOLD 1
TEXT 8 0 24 470 运单编号： 4000 0105 3067 2
SETBOLD 0
TEXT 55 0 32 600 收件人/代签人：
TEXT 55 0 32 634 签收时间：     年   月   日
TEXT 8 0 32 684 4000010530672
SETBOLD 0
TEXT 55 0 24 782 发件人： 邓先生
TEXT 55 0 24 802 电话：  13155558888
TEXT 55 0 24 822 发件地址： 上海市,上海市,青浦区上海市上海市青浦区
TEXT 55 0 24 842 盈港东路6679号
TEXT 55 0 32 862 收件人： 吴先生
TEXT 55 0 32 882 电话：  13800138001
TEXT 55 0 32 902 收件地址： 上海市,上海市,青浦区上海市上海市青浦区
TEXT 55 0 32 922 盈港东路6679号
TEXT 55 0 440 782
TEXT 55 0 440 802
TEXT 55 0 440 822
TEXT 55 0 440 842
TEXT 55 0 24 964 发件人： 邓先生
TEXT 55 0 24 984 电话：  13155558888
TEXT 55 0 24 1004 发件地址： 上海市,上海市,青浦区上海市上海市青浦区
TEXT 55 0 24 1024 盈港东路6679号
TEXT 55 0 32 1044 收件人： 吴先生
TEXT 55 0 32 1064 电话：  13800138001
TEXT 55 0 32 1084 收件地址： 上海市,上海市,青浦区上海市上海市青浦区
TEXT 55 0 32 1104 盈港东路6679号
TEXT 55 0 448 1105 2015/3/11
TEXT 55 0 448 1120 14:6:23
SETBOLD 1
TEXT 24 0 448 1055 0.000 KG
TEXT 24 0 448 1080 逆向物流
TEXT 8 0 32 1135 运单编号： 4000 0105 3067 2
SETBOLD 0
TEXT 55 0 24 1168 官方网址： http://www.yundaex.com 客服热线： 400-821-6789  发货人联
B 128 2 1 48 292 118 200000
B QR 32 216 M 2 U 5
MA, 4000010530672200000
ENDQR
B 128 2 1 50 23 714 4000010530672
VB 128 2 2 80 470 662 400001053067208418
GAP-SENSE
FORM
PRINT

*/

/////////////////////////////////////////////BEGIN/////////////////////////////////////////////

	ret=CPCL_PageSetup(0,1256,1,0);
	if( ret<0)
	{	
		printf("CPCL_PageSetup() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_PageSetup() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(12,192,576,192,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(12,448,440,448,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(12,512,440,512,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(12,775,576,775,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(12,1162,576,1162,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(440,192,440,670,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_DrawLine(440,775,440,940,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);

	ret=CPCL_SetBold(0);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
//////////////////////////////////////////文字打印//////////////////////////////////////////////
	char *imagePath = "goodwork.bmp";
	ret=CPCL_PrintBMP(0,0,100,imagePath);
	if( ret<0)
	{	
		printf("CPCL_PrintBMP() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_PrintBMP() ok ret=%d\n",ret);


	ret=CPCL_DrawText(0,55,0,24,8,"始发网点： 网点程序测试");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,80,40,"收件人： 吴先生");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,80,60,"电话：  13800138001");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,80,80,"收件地址： 上海市,上海市,青浦区上海市上海市青浦区");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,80,100,"盈港东路6679号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,448,8,"体积：");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,448,28,"2015/3/11");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,448,48,"14:6:23");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(1);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,24,40,"送达");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,24,65,"地址");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,3,16,160,"集包地：上海XX分包中心");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,328,8,"5 KG");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,328,33,"逆风物流");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(1);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,5,136,368,"沪青浦");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,4,1,200,200,"1 8 5");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,4,1,200,280,"9 6");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(1);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,8,0,24,470,"运单编号： 4000 0105 3067 2");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(0);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,32,600,"收件人/代签人：");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,32,634,"签收时间：     年   月   日");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,8,0,32,684,"4000010530672");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(0);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,782,"发件人： 邓先生");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,802,"电话：  13155558888");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,822,"发件地址： 上海市,上海市,青浦区上海市上海市青浦区");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,842,"盈港东路6679号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,32,862,"收件人： 吴先生");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,32,882,"电话：  13800138001");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,32,902,"收件地址： 上海市,上海市,青浦区上海市上海市青浦区");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,32,922,"盈港东路6679号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,964,"发件人： 邓先生");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,984,"电话：  13155558888");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,1004,"发件地址： 上海市,上海市,青浦区上海市上海市青浦区");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,1024,"盈港东路6679号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,1044,"收件人： 吴先生");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,1064,"电话：  13800138001");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,34,1084,"收件地址： 上海市,上海市,青浦区上海市上海市青浦区");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,34,1104,"盈港东路6679号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,448,1105,"2015/3/11");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,448,1120,"14:6:23");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(1);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,448,1055,"0.000 KG");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,448,1080,"逆风物流");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,8,0,32,1135,"运单编号： 4000 0105 3067 2");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(0);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,55,0,24,1168,"官方网址： http://www.yundaex.com 客服热线： 400-821-6789  发货人联");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);

//////////////////////////////////////////文字打印//////////////////////////////////////////////
//条码打印
	ret=CPCL_DrawBarcode(0,"128",2,1,48,292,118,"200000");
	if( ret<0)
	{	
		printf("CPCL_DrawBarcode() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawBarcode() ok ret=%d\n",ret);

	ret=CPCL_Draw2Barcode_QR(32,216,2,5,"M","4000010530672200000");
	if( ret<0)
	{	
		printf("CPCL_Draw2Barcode_QR() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_Draw2Barcode_QR() ok ret=%d\n",ret);

	ret=CPCL_DrawBarcode(0,"128",2,1,50,23,714,"4000010530672");
	if( ret<0)
	{	
		printf("CPCL_DrawBarcode() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawBarcode() ok ret=%d\n",ret);

	ret=CPCL_DrawBarcode(1,"128",2,2,80,470,662,"400001053067208418");
	if( ret<0)
	{	
		printf("CPCL_DrawBarcode() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawBarcode() ok ret=%d\n",ret);

//打印并找缝隙
	ret=CPCL_Form();
	if( ret<0)
	{	
		printf("CPCL_Form() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_Form() ok ret=%d\n",ret);
	
	ret=CPCL_Print();
	if( ret<0)
	{	
		printf("CPCL_Print() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_Print() ok ret=%d\n",ret);

//////////////////////////////////////////////END//////////////////////////////////////////////

	ret=ClosePort();
	if( ret<0)
	{	
		printf("ClosePort() fail ret=%d\n",ret);
		return;
	}
	else
	{
		printf("ClosePort() ok ret=%d\n",ret);
	}			
	
	
}	 
