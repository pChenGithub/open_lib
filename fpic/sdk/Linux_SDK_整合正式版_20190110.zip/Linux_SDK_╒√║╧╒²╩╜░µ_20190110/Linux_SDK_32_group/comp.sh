gcc -fPIC -c HWISPRTPrinter.c -o HWISPRTPrinter.o -I ./ -I /usr/local/include/libusb-1.0 -L/usr/local/lib -lusb-1.0
gcc -fPIC -c sprtGraphic.c -o sprtGraphic.o -I ./ -I /usr/local/include/libusb-1.0 -L/usr/local/lib -lusb-1.0
gcc HWISPRTPrinter.o sprtGraphic.o  -o libHWISPRTPrinter.so -fPIC -shared
gcc  -o GtestMain -I /usr/local/include/libusb-1.0 -I ./ GtestMain.c -L./ -lHWISPRTPrinter -L/usr/local/lib -lusb-1.0
gcc  -o CPCLtest -I /usr/local/include/libusb-1.0 -I ./ CPCLtest.c -L./ -lHWISPRTPrinter -L/usr/local/lib -lusb-1.0
gcc  -o TSPLtest -I /usr/local/include/libusb-1.0 -I ./ TSPLtest.c -L./ -lHWISPRTPrinter -L/usr/local/lib -lusb-1.0
gcc  -o testMain -I /usr/local/include/libusb-1.0 -I ./ testMain.c -L./ -lHWISPRTPrinter -L/usr/local/lib -lusb-1.0
gcc  -o CPCLDemo -I /usr/local/include/libusb-1.0 -I ./ CPCLDemo.c -L./ -lHWISPRTPrinter -L/usr/local/lib -lusb-1.0
