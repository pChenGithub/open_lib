
#ifndef SPRTGRAPHIC_H
#define SPRTGRAPHIC_H


#ifdef __cplusplus
extern "C"
{
#endif

#pragma pack(2)
/*typedef struct tagBITMAPFILEHEADER {
        unsigned short    bfType;
        unsigned long    	bfSize;
        unsigned short    bfReserved1;
        unsigned short    bfReserved2;
        unsigned long    	bfOffBits;
} BITMAPFILEHEADER, *PBITMAPFILEHEADER;


typedef struct tagBITMAPINFOHEADER{
        unsigned long     biSize;
        long       				biWidth;
        long       				biHeight;
        unsigned short	 	biPlanes;
        unsigned short    biBitCount;
        unsigned long     biCompression;
        unsigned long     biSizeImage;
        long       				biXPelsPerMeter;
        long       				biYPelsPerMeter;
        unsigned long     biClrUsed;
        unsigned long     biClrImportant;
} BITMAPINFOHEADER, *PBITMAPINFOHEADER;
*/
typedef struct tagBITMAPFILEHEADER {
        unsigned short    bfType;
        int   	          bfSize;
        unsigned short    bfReserved1;
        unsigned short    bfReserved2;
        int    	          bfOffBits;
} BITMAPFILEHEADER, *PBITMAPFILEHEADER;


typedef struct tagBITMAPINFOHEADER{
        int               biSize;
        int      				  biWidth;
        int        				biHeight;
        unsigned short	 	biPlanes;
        unsigned short    biBitCount;
        int               biCompression;
        int               biSizeImage;
        int        				biXPelsPerMeter;
        int        				biYPelsPerMeter;
        int               biClrUsed;
        int               biClrImportant;
} BITMAPINFOHEADER, *PBITMAPINFOHEADER;


typedef struct tagRGBQUAD {
        unsigned char    rgbBlue;
        unsigned char    rgbGreen;
        unsigned char    rgbRed;
        unsigned char    rgbReserved;
} RGBQUAD;

extern int m_iWidth;			// 实际宽度;
extern int m_iHeight;			// 实际高度;
extern unsigned char *m_lpBuffer;			// 图形数据缓冲区;

// 校验用户bmp图像数据格式及初始化相关变量; 0:成功，其他：失败；
int InitUserBMP(const char *bitmap);
// 校验用户bmp图像数据格式及获得数据偏移量;
int ValidUserBMP(const char *bitmap,int *dataOffset);

// 打开bmp位图文件; 0:成功，其他：失败；
int OpenBmpFile(unsigned char *szFile);
// 查询文件是否符合规定，如果符合单色位图
// 则记录文件的尺寸，并且返回数据的尺寸
int ValidBMP(FILE *hBmp);
// 反向处理图像
void ReverseBitmap(unsigned char  *lpOrg, unsigned char *lpBuff);
// 处理掉图像的填充位
void FeedEmptyBit(unsigned char *lpBuff, int iHeight, int iOrgWid, int iObtWid);
//下载位图1B，FE
// 返回数据长度;  <0:失败;
int InitDownloadImage(unsigned char *path, int position);
// 校验用户bmp图像数据格式及获得数据大小;
// >0:数据大小，其他：失败;
int GetUserDownLoadBMPSize(unsigned char *bitmap);
//下载位图1B，FE
// 返回数据长度;  <0:失败;
int InitUserBMPDownloadImage(unsigned char *img, int position);
// 校验用户bmp图像数据格式及获得数据大小;
// >0:数据大小，其他：失败;
int GetUserDownLoadBMPSize(unsigned char *bitmap);
// 查询文件是否符合规定，如果符合单色位图
// 则记录文件的尺寸，并且返回数据的尺寸
int GetValidBMPFileSize(unsigned char *szFile);

// 将图片数据转化为指令 1D 44 01 15 n 16 n ...
//
// 参数：
//		pszBuffer	解析后的缓冲区数据
//
// 返回值：
//		返回发送缓冲区的大小，以便后来程序调用
//
int MakeCmdBuffer(char **pszBuffer);

#ifdef __cplusplus
}
#endif

#endif
