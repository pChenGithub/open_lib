
#include <stdio.h>
#include "HWISPRTPrinter.h"
//include <libusb.h>

void main()
{
	int ret=-1;

	//char *ipAddress  = "192.168.1.114"; //网口,WX_20160811
	char ip[256];
	bzero(ip, 256);
	printf("Please Input File Name Upload To Server: ");
	scanf("%s", ip);

	setAttribute(NET_PORT);
	ret=OpenPort(ip);
	if( ret<0)
	{	
		printf("OpenPort() fail ret=%d\n",ret);
		return;
	}
	printf("OpenPort() ok ret=%d\n",ret);

/*************************************************************************/	
	// 初始化打印机;
	ret=POS_Control_ReSet();
	if( ret<0)
	{
		printf("POS_Control_ReSet() fail ret=%d\n",ret);
		ret=Sprt_usb_close();
		printf("Sprt_usb_close() finished, ret=%d\n",ret);
		
		return;
	}
	printf("POS_Control_ReSet() ok ret=%d\n",ret);	


/////////////////////////////////////////////BEGIN/////////////////////////////////////////////
//设置标签纸大小
	ret=TSPL_PageSetup(56,60);
	if( ret<0)
	{	
		printf("TSPL_PageSetup() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PageSetupn() ok ret=%d\n",ret);

//清除缓存区内容
	ret=TSPL_CLS();
	if( ret<0)
	{	
		printf("TSPL_CLS() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_CLS() ok ret=%d\n",ret);

//设置标签的参考坐标原点
	ret=TSPL_SetLabelReference(90,0);
	if( ret<0)
	{	
		printf("TSPL_SetLabelReference() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_SetLabelReference() ok ret=%d\n",ret);

//横线上方区域
	ret=TSPL_PrintText(5,15,0,0,1,1,"汉步");
	if( ret<0)
	{	
		printf("TSPL_PrintText() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintText() ok ret=%d\n",ret);

	ret=TSPL_PrintText(5,37,0,0,1,1,"HanBu");
	if( ret<0)
	{	
		printf("TSPL_PrintText() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintText() ok ret=%d\n",ret);

	ret=TSPL_PrintText(70,15,0,0,2,2,"热敏不干胶纸");
	if( ret<0)
	{	
		printf("TSPL_PrintText() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintText() ok ret=%d\n",ret);
	
//画线
	ret=TSPL_DrawLine(5,68,350,10);
	if( ret<0)
	{	
		printf("TSPL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_DrawLine() ok ret=%d\n",ret);

//横线下方区域
	ret=TSPL_PrintBarCode2D(5,85,"QRCODE","L",4,0,"www.sprinter.com.cn");
	if( ret<0)
	{	
		printf("TSPL_PrintBarCode2D() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintBarCode2D() ok ret=%d\n",ret);

	ret=TSPL_PrintText(130,90,0,0,2,2,"SIZE:");
	if( ret<0)
	{	
		printf("TSPL_PrintText() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintText() ok ret=%d\n",ret);

	ret=TSPL_PrintText(130,150,0,0,2,2,"40MM*30MM");
	if( ret<0)
	{	
		printf("TSPL_PrintText() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintText() ok ret=%d\n",ret);

	ret=TSPL_PrintBarCode(5, 200, "128", 100, 1, 0, 1, 2, "12345678901234");
	if( ret<0)
	{	
		printf("TSPL_PrintBarCode() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_PrintBarCode() ok ret=%d\n",ret);

//打印
	ret=TSPL_Print(1, 1);
	if( ret<0)
	{	
		printf("TSPL_Print() fail ret=%d\n",ret);
		return;
	}
	printf("TSPL_Print() ok ret=%d\n",ret);
//////////////////////////////////////////////END//////////////////////////////////////////////

	ret=ClosePort();
	if( ret<0)
	{	
		printf("ClosePort() fail ret=%d\n",ret);
		return;
	}
	else
	{
		printf("ClosePort() ok ret=%d\n",ret);
	}			
	
	
}	 
