#include <stdio.h>
#include "HWISPRTPrinter.h"
//include <libusb.h>

void main()
{
	int ret=-1;

	/*char ip[256];
	bzero(ip, 256);
	printf("Please Input IP: ");
	scanf("%s", ip);

	ret=Sprt_net_open(ip);
	if(ret<0)
	{	
		printf("Sprt_net_open() fail ret=%d\n",ret);
		return;
	}
	printf("Sprt_net_open() ok ret=%d\n",ret);*/

	/*ret=Sprt_usb_open();
	if( ret<0)
	{	
		printf("Sprt_usb_open() fail ret=%d\n",ret);
		return;
	}
	printf("Sprt_usb_open() ok ret=%d\n",ret);*/


 	// OK 2016.12.21. 16:27
	
	ret	=	OpenPort(USB_PORT,NULL);
	if( ret<0)
	{	
		printf("OpenPort() fail ret=%d\n",ret);
		return;
	}
	printf("OpenPort() ok ret=%d\n",ret);
	
	// 初始化打印机;
	ret=POS_Control_ReSet();
	if(ret<0)
	{	
		printf("POS_Control_ReSet() fail ret=%d\n",ret);
		ret=ClosePort();
		printf("ClosePort() finished, ret=%d\n",ret);
		
		return;
	}
	printf("POS_Control_ReSet() ok ret=%d\n",ret);	
/*******************************************CPCL********************************************/
	ret=CPCL_PageSetup(0,385,1,720);
	if( ret<0)
	{	
		printf("CPCL_PageSetup() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_PageSetup() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,24,709,24,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,72,709,72,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,120,709,120,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,168,709,168,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,216,709,216,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,272,709,272,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,384,709,384,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(0,24,0,384,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(153,24,153,384,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(709,24,709,384,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(226,220,226,272,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(427,73,427,272,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_DrawLine(499,73,499,272,1);
	if( ret<0)
	{	
		printf("CPCL_DrawLine() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawLine() ok ret=%d\n",ret);
	
	ret=CPCL_SetUnderLineText(0);
	if( ret<0)
	{	
		printf("CPCL_SetUnderLineText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetUnderLineText() ok ret=%d\n",ret);
	
	ret=CPCL_SetBold(1);
	if( ret<0)
	{	
		printf("CPCL_SetBold() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetBold() ok ret=%d\n",ret);
	
	ret=CPCL_SetInverseText(0);
	if( ret<0)
	{	
		printf("CPCL_SetInverseText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetInverseText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,33,37,"仓库位置");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,295,37,"东边一号仓库(西一排3号)");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,33,86,"物资编号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,240,86,"567824619");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,443,86,"单位");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,576,86,"盒");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,33,135,"物资名称");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,285,135,"螺丝钉");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,443,135,"单价");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,558,135,"12.68");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,33,184,"规格型号");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,264,184,"小85A");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,443,184,"产地");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,564,184,"上海");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,33,237,"储备定额");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,170,237,"最高");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,307,237,"3256");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,443,237,"最低");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,564,237,"1869");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,45,314,"条形码");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawText(0,24,0,375,358,"123456789012");
	if( ret<0)
	{	
		printf("CPCL_DrawText() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawText() ok ret=%d\n",ret);
	
	ret=CPCL_DrawBarcode(0,"128",1,1,72,350,280,"123456789012");
	if( ret<0)
	{	
		printf("CPCL_DrawBarcode() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_DrawBarcode() ok ret=%d\n",ret);
	
	ret=CPCL_Draw2Barcode_QR(590,280,2,3,"M","4000010530672200000");
	if( ret<0)
	{	
		printf("CPCL_Draw2Barcode_QR() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_Draw2Barcode_QR() ok ret=%d\n",ret);
	
	ret=CPCL_PrintBMP(1,200,280,"LOGO.bmp");
	if( ret<0)
	{	
		printf("CPCL_PrintBMP() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_PrintBMP() ok ret=%d\n",ret);
	
	ret=CPCL_SetPageRoate(1);
	if( ret<0)
	{	
		printf("CPCL_SetPageRoate() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_SetPageRoate() ok ret=%d\n",ret);
	
	ret=CPCL_Print();
	if( ret<0)
	{	
		printf("CPCL_Print() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_Print() ok ret=%d\n",ret);
	
/*******************************************CPCL********************************************/
	//ret=ClosePort();
	//if(ret<0)
	//{	
	//	printf("ClosePort() fail ret=%d\n",ret);
	//	return;
	//}
	//else
	//{
	//	printf("ClosePort() ok ret=%d\n",ret);
	//}	
	
	ret=ClosePort();
	if( ret<0)
	{	
		printf("ClosePort() fail ret=%d\n",ret);
		return;
	}
	else
	{
		printf("ClosePort() ok ret=%d\n",ret);
	}		
	
}