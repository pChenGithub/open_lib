
#include <stdio.h>
#include "HWISPRTPrinter.h"
//include <libusb.h>

void main()
{
	int ret=-1;

	
	ret=OpenPort(USB_PORT,NULL);
	if( ret<0)
	{	
		printf("OpenPort() fail ret=%d\n",ret);
		return;
	}
	printf("OpenPort() ok ret=%d\n",ret);

/*************************************************************************/
	
//位图打印测试(ESC/POS)

	//char *imagePath = "goodwork.bmp";
	//ret = POS_Output_PrintBmpDirect(imagePath);
	//if( ret<0)
	//{	
	//	printf("POS_Output_PrintString() fail ret=%d\n",ret);
	//	ret=OpenPort();
	//	printf("Sprt_net_close() finished, ret=%d\n",ret);
	//	return;
	//}
	//printf("POS_Output_PrintString() ok ret=%d\n",ret);

//位图打印测试(CPCL)
	ret=CPCL_PageSetup(0,500,1,0);
	if( ret<0)
	{	
		printf("CPCL_PageSetup() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_PageSetup() ok ret=%d\n",ret);

	char *imagePath = "goodwork.bmp";
	ret=CPCL_PrintBMP(1,5,5,imagePath);
	if( ret<0)
	{	
		printf("CPCL_PrintBMP() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_PrintBMP() ok ret=%d\n",ret);

	
	ret=CPCL_Print();
	if( ret<0)
	{	
		printf("CPCL_Print() fail ret=%d\n",ret);
		return;
	}
	printf("CPCL_Print() ok ret=%d\n",ret);

	
/*************************************************************************/	
	ret=OpenPort();
	if( ret<0)
	{	
		printf("OpenPort() fail ret=%d\n",ret);
		return;
	}
	else
	{
		printf("OpenPort() ok ret=%d\n",ret);
	}			
	
}	 
